# Private account review — setup and acceptance

Status: local implementation, not a public deployment. The real Supabase/SMTP
acceptance gate must pass before entering customer data. Do not enable public signup.

## Configuration agreed with the owner

- Supabase Free, a separate `runners-passport-review` project, London eu-west-2.
- Resend Free custom SMTP; verify a dedicated sending subdomain.
- Local API/website at `http://127.0.0.1:8893`, bound to loopback only.
- No paid upgrades, production deployment, GitHub auto-deploy link or live-domain changes.
- Existing device drafts remain at their original browser origin. The earlier site
  on port 8892 remains available. Copying to an account is always explicit.

## 1. Supabase project (owner steps)

Create the review project under the business-owned free organisation. Save the
database password in your password manager; the app does not need that password.
Keep Data API enabled, disable automatically exposing new tables, enable automatic
RLS. Leave GitHub deployment integration unconnected.

Run every SQL file in `supabase/migrations/` in filename order. The first migration
is for an empty review project, not a reset over an existing production database.
The two subsequent corrections accommodate Storage's pre-upload permission probe;
the final policy rejects missing size and checks `size` or provider `contentLength`.
Do not stop after migration 002: it is superseded by 003. All three have been
applied to the isolated review project. They create private buckets, owner
permissions, invitation restrictions, quotas and a retryable deletion queue.

In Auth settings:

- Email provider enabled; **new user signup disabled**; anonymous sign-ins disabled.
- Other login providers disabled. Strava/Garmin are not account login providers.
- Site URL is the local review origin. Do not add the public website as a redirect.
- Use an email OTP template displaying `{{ .Token }}` for both magic-link/login
  and confirmation mail. No login link is needed for this UI.
- The prepared template is `server/templates/auth-code.html`; subject:
  `Your Runner's Passport sign-in code`. It contains no remote tracking images.
- Set email-code expiry to ten minutes; retain provider resend/rate limits.
- Retain the provider's refresh-token reuse interval; browser requests are also
  serialised through Web Locks where supported. Test expiry/refresh in two tabs.
- Use a short access-token expiry (for example 15 minutes). Our RLS also checks
  whether the provider session still exists, rather than relying on expiry alone.

## 2. Resend email (owner steps)

Add a dedicated sending subdomain such as `auth.myrunnerspassport.com`. Copy the
exact DNS records Resend supplies to your DNS provider. Do not replace existing
website or mailbox DNS records. Verify the domain before using customer addresses.

Create a sending-only API credential restricted to the verified domain where the
service supports it. Configure Supabase's Custom SMTP using Resend's current SMTP
host/port and credential instructions; do not put this key in browser JavaScript.
Use a recognisable sender, e.g. `Runner's Passport <passport@auth.myrunnerspassport.com>`.
Disable open/click tracking for authentication email. Test inbox and spam delivery.

Resend's sandbox sender can be used for an owner-only mail check, but is not a
substitute for verified-domain delivery to invited testers.

## 3. Server configuration (never in chat or Git)

The server requires `APP_ORIGIN`, `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`,
`SUPABASE_SECRET_KEY`, `REVIEW_ONLY=true`, and optional `PORT` (default 8893).
Keep `AUTH_EMAIL_READY=false` until SMTP, OTP templates and real inbox delivery
have been verified. A connected database alone does not enable email sign-in.
The publishable and secret values are from the **review** project only.

Prefer an environment file outside this OneDrive-synchronised repository, e.g.
`%LOCALAPPDATA%\RunnersPassport\review.env`, readable by your Windows account.
The `.env.example` file documents variable names and contains no credentials.
An ignored `.dev.vars` is supported for convenience but may still be synchronised
by OneDrive; Git-ignore does not prevent cloud sync. Do not use it for production secrets.

From this source directory (Node 22.16+):

```powershell
node scripts/make-pages.mjs
node scripts/check-site.mjs
node build.mjs
node --env-file="C:\path\outside\OneDrive\review.env" server/local.mjs
```

Use the installed package manager's frozen lockfile install if dependencies need
restoring. `pnpm-lock.yaml` pins official Supabase libraries; PGlite is test-only.
The API is written against standard Request/Response and is Cloudflare-compatible.
No public Worker deployment configuration or publish command is included.

## 4. Admit an invited reviewer

```powershell
node --env-file="C:\path\outside\OneDrive\review.env" scripts/invite-reviewer.mjs
```

The command prompts for an email; it does not send a message. The reviewer requests
their own code on `/account.html`. They prove mailbox ownership with that code.
Do not turn public signup on to work around an invitation or SMTP error.

## 5. Device drafts and migration

Nothing automatically uploads at sign-in. Account Memories lists local drafts for
this origin; the reviewer checks each one and chooses Copy selected drafts.

For drafts on port 8892, open Saved drafts there and choose **Export private drafts
for account migration**. At port 8893, sign in and select Import a draft file. The
file is initially read only in the browser; select its drafts to upload. The file
contains photographs and must be treated as private. It is not copied to localStorage
at the new origin. Existing originals are never removed by migration.

Retries match owner + legacy draft ID + exact snapshot fingerprint. A changed
snapshot becomes a new copy, protecting both versions. Partial failures report
per-draft results and can be retried without duplicating successful snapshots.
The app reads back the photo bytes and framing after each copy. Existing compressed
device photos cannot recover detail from an original that was never retained.

Cloud editor changes upload only after Save to my account. Device-save and download
remain separate. Account drafts use version checks; stale saves return a conflict.
Customer files use opaque owner-prefixed paths, private buckets and authenticated
API downloads, not public or long-lived signed links.

## 6. Recovery, signout and deletion

New email code + same mailbox reopens the same account; there is no password to
reset. Lost mailbox access must be recovered through the mailbox provider. Email
address changes and manual support recovery are not enabled in this review.

Signout-this-device and signout-all-devices are separate. Cloud state is memory-only,
private responses are no-store, account switches cancel requests and clear previews.
The personaliser locks when its owning account changes.

Deletion requires a newly authenticated provider session from the last ten minutes
and typing DELETE. It first locks access via a database tombstone, then removes
Storage files via the Storage API, then deletes the Auth user (cascading private
rows). A minimal job record remains to make retries safe. The local server retries
pending jobs every minute **while it is running**. If stopped, retries resume on the
next run. An eventual hosted deployment needs a protected scheduled worker.
The UI says “requested” until removal is verified; it does not falsely promise
instant deletion. Provider backups obey provider retention. Independent local
drafts/downloads remain outside account deletion.

## 7. Acceptance gates

Local executable checks:

```powershell
node --test tests/account-unit.test.mjs tests/account-policies.test.mjs
```

These execute the actual SQL migration in PGlite/PostgreSQL with small fixture Auth
and Storage schemas. They verify owner access, denial across users, immutable
objects, quotas, version conflicts, idempotent migration, revoked sessions and
deletion locks. They do **not** verify Supabase's real Auth/Storage services.

Live service check, only on the isolated project:

Add `TEST_LIVE_SUPABASE=true` and `REVIEW_PROJECT_REF=<review-project-ref>` to the
private environment file, then:

```powershell
node --env-file="C:\path\outside\OneDrive\review.env" --test tests/account-isolation.test.mjs
```

The suite creates two synthetic accounts, uses ordinary customer sessions for
access assertions, and cleans up only its fixtures. Admin access is used solely for
fixture creation/cleanup and account deletion. It checks direct DB/Storage access
as well as API access, known IDs/paths, import retry, exact bytes/framing, stale
updates, forged purchase fields, recovery, concurrent reads and account deletion.
It sends no email. Missing configuration reports **skipped**, not security passed.

Before declaring the review connected, also perform:

- Real inbox code delivery, wrong/expired/reused code, resend limit, email outage.
- Two-tab expiry/refresh and shared-browser account switch while saving/uploading.
- Real local-draft export/import with explicit selection and a partial failed upload.
- Photo drag, zoom, crop, downloaded preview and mobile keyboard/accessibility.
- Interrupted deletion and restart; verify files, DB and Auth removal actually finish.
- Inspect built static files and network traffic: no admin key, customer tokens,
  hidden artwork or private photos in the static bundle/cache.

No public launch until these pass and the owner approves it.

## Cost controls

No paid subscription or card required by this local implementation. Use only the
approved free plans, monitor storage/mail limits, and never automatically upgrade.
Review limits in code: 100 drafts and 50 MiB reserved image storage per account;
10 MiB maximum single upload. Reservation failures retain local copies. On a partial
upload, unreachable cleanup can leave quota reserved; investigate/release abandoned
reservations before expanding quotas. Live service behaviour and current plan limits
must still be checked in the dashboards.
