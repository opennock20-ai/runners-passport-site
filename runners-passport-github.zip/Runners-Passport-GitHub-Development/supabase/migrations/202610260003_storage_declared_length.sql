-- Tighten the initial probe: reject missing size instead of permitting it.
-- Newer Storage versions expose contentLength during permission probing.
alter policy rp_object_insert on storage.objects with check (
  rp_private.owns_object(name,bucket_id)
  and exists (
    select 1 from public.rp_assets a
    where a.path=storage.objects.name and a.owner_id=auth.uid()
      and coalesce((storage.objects.metadata->>'size')::bigint,
                   (storage.objects.metadata->>'contentLength')::bigint) <= a.byte_size
  )
);
