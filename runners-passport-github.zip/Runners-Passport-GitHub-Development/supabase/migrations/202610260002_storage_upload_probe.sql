-- HISTORICAL correction, superseded by migration 003. Apply all migrations.
-- Storage probes INSERT permission before upload with no final `size` metadata.
-- Permit that probe only for a reserved, owned object. Storage rechecks the
-- caller's policy with authoritative size on completion in some versions.
-- Live testing disproved this assumption on this project; migration 003 instead
-- requires the provider's initial contentLength. Never stop after this migration.
alter policy rp_object_insert on storage.objects with check (
  rp_private.owns_object(name,bucket_id)
  and exists (
    select 1 from public.rp_assets a
    where a.path=storage.objects.name and a.owner_id=auth.uid()
      and ((storage.objects.metadata->>'size') is null
           or (storage.objects.metadata->>'size')::bigint <= a.byte_size)
  )
);
