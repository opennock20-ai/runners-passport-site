-- Run once in a NEW, isolated Supabase review project, as postgres.
-- No public signup: add invited emails below via the setup tool BEFORE creating users.
begin;
create schema if not exists rp_private;
revoke all on schema rp_private from public, anon, authenticated;
create table rp_private.invited_emails (email text primary key check (email=lower(email)));
create table public.rp_profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null default '' check (length(display_name)<=60),
 lifecycle text not null default 'active' check(lifecycle in ('active','deleting')),
 created_at timestamptz not null default now()
);
create table rp_private.deletion_jobs (
 user_id uuid primary key, state text not null default 'pending', attempts integer not null default 0,
 requested_at timestamptz not null default now(), completed_at timestamptz
);
alter table rp_private.invited_emails enable row level security;
alter table rp_private.deletion_jobs enable row level security;
-- A user cannot admit themselves by editing metadata, including user_metadata.
create function rp_private.create_profile() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from rp_private.invited_emails where email=lower(new.email)) then
   raise exception 'Review invitation required';
 end if;
 insert into public.rp_profiles(id) values(new.id);
 return new;
end $$;
create trigger rp_new_user after insert on auth.users for each row execute function rp_private.create_profile();
-- Check the provider session itself, so an unexpired JWT from a logged-out/deleted
-- session does not retain database or object access. No JWT is decoded by our API.
create function rp_private.active() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.rp_profiles p join auth.users u on u.id=p.id
 join rp_private.invited_emails i on i.email=lower(u.email)
 where p.id=(select auth.uid()) and p.lifecycle='active')
 and exists(select 1 from auth.sessions s where s.user_id=(select auth.uid())
 and s.id::text=(select auth.jwt()->>'session_id'));
$$;
revoke all on function rp_private.active() from public,anon,authenticated;
grant usage on schema rp_private to authenticated;
grant execute on function rp_private.active() to authenticated;
revoke all on function rp_private.create_profile() from public,anon,authenticated;
alter table public.rp_profiles enable row level security;
revoke all on public.rp_profiles from public,anon,authenticated;
grant select on public.rp_profiles to authenticated;
grant update(display_name) on public.rp_profiles to authenticated;
create policy rp_profile_read on public.rp_profiles for select to authenticated using(id=(select auth.uid()) and (select rp_private.active()));
create policy rp_profile_edit on public.rp_profiles for update to authenticated using(id=(select auth.uid()) and (select rp_private.active())) with check(id=(select auth.uid()) and (select rp_private.active()));

create table public.rp_assets (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.rp_profiles(id) on delete cascade,
 kind text not null check(kind in ('photo','preview')), mime text not null check(mime in ('image/jpeg','image/png','image/webp')),
 byte_size integer not null check(byte_size between 1 and 10485760),
 path text not null unique, created_at timestamptz not null default now(), unique(owner_id,id)
);
create index rp_assets_owner on public.rp_assets(owner_id);
create table public.rp_drafts (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.rp_profiles(id) on delete cascade,
 card_id text not null check(card_id in ('plymouth','nevis','cycle','coast','richmond')),
 name text not null check(length(name) between 1 and 50), caption text not null check(length(caption) between 1 and 60),
 primary_stat text not null check(length(primary_stat) between 1 and 24), distance text not null check(length(distance) between 1 and 24),
 event_date date not null check(event_date between '1900-01-01' and '2100-12-31'),
 photo_x numeric not null default 50 check(photo_x between 0 and 100), photo_y numeric not null default 50 check(photo_y between 0 and 100),
 photo_zoom numeric not null default 1 check(photo_zoom between 1 and 3),
 photo_id uuid, preview_id uuid not null,
 version integer not null default 1, updated_at timestamptz not null default now(),
 legacy_id text check(length(legacy_id)<=120), fingerprint text check(fingerprint ~ '^[a-f0-9]{64}$'),
 unique(owner_id,legacy_id,fingerprint),
 foreign key(owner_id,photo_id) references public.rp_assets(owner_id,id),
 foreign key(owner_id,preview_id) references public.rp_assets(owner_id,id)
);
create index rp_drafts_owner on public.rp_drafts(owner_id);
alter table public.rp_assets enable row level security;
alter table public.rp_drafts enable row level security;
revoke all on public.rp_assets, public.rp_drafts from public,anon,authenticated;
grant select on public.rp_assets,public.rp_drafts to authenticated;
-- Writes use narrow RPCs with active-owner checks, quotas and optimistic concurrency.
create policy rp_assets_read on public.rp_assets for select to authenticated using(owner_id=(select auth.uid()) and (select rp_private.active()));
create policy rp_drafts_read on public.rp_drafts for select to authenticated using(owner_id=(select auth.uid()) and (select rp_private.active()));

create function public.rp_reserve_asset(p_kind text,p_mime text,p_size integer) returns public.rp_assets language plpgsql security definer set search_path='' as $$
declare result public.rp_assets; uid uuid:=auth.uid(); aid uuid:=gen_random_uuid();
begin
 if not rp_private.active() then raise exception 'Not permitted' using errcode='42501'; end if;
 perform 1 from public.rp_profiles where id=uid for update;
 if not rp_private.active() then raise exception 'Not permitted' using errcode='42501'; end if;
 if (select coalesce(sum(byte_size),0) from public.rp_assets where owner_id=uid)+p_size>52428800 then raise exception 'Review photo allowance reached' using errcode='P0001'; end if;
 insert into public.rp_assets(id,owner_id,kind,mime,byte_size,path) values(aid,uid,p_kind,p_mime,p_size,uid::text||'/'||aid::text) returning * into result;
 return result;
end $$;
create function public.rp_save_draft(p_id uuid,p_version integer,p_data jsonb,p_legacy text default null,p_fingerprint text default null) returns public.rp_drafts language plpgsql security definer set search_path='' as $$
declare result public.rp_drafts; uid uuid:=auth.uid(); photo uuid:=(p_data->>'photo_id')::uuid; preview uuid:=(p_data->>'preview_id')::uuid;
begin
 if not rp_private.active() then raise exception 'Not permitted' using errcode='42501'; end if;
 perform 1 from public.rp_profiles where id=uid for update;
 if not rp_private.active() then raise exception 'Not permitted' using errcode='42501'; end if;
 if (p_legacy is null)<>(p_fingerprint is null) then raise exception 'Invalid migration'; end if;
 if p_legacy is not null then
   select * into result from public.rp_drafts where owner_id=uid and legacy_id=p_legacy and fingerprint=p_fingerprint;
   if found then return result; end if;
 end if;
 -- References must belong to this account, have the right kind, and be uploaded.
 if not exists(select 1 from public.rp_assets a join storage.objects o on o.name=a.path and o.bucket_id='draft-previews' where a.id=preview and a.owner_id=uid and a.kind='preview') then raise exception 'Preview not available' using errcode='42501'; end if;
 if photo is not null and not exists(select 1 from public.rp_assets a join storage.objects o on o.name=a.path and o.bucket_id='customer-photos' where a.id=photo and a.owner_id=uid and a.kind='photo') then raise exception 'Photo not available' using errcode='42501'; end if;
 if p_id is null then
   if (select count(*) from public.rp_drafts where owner_id=uid)>=100 then raise exception 'Review draft allowance reached'; end if;
   insert into public.rp_drafts(owner_id,card_id,name,caption,primary_stat,distance,event_date,photo_x,photo_y,photo_zoom,photo_id,preview_id,legacy_id,fingerprint)
   values(uid,p_data->>'card_id',p_data->>'name',p_data->>'caption',p_data->>'primary_stat',p_data->>'distance',(p_data->>'event_date')::date,(p_data->>'photo_x')::numeric,(p_data->>'photo_y')::numeric,(p_data->>'photo_zoom')::numeric,photo,preview,p_legacy,p_fingerprint) returning * into result;
 else
   update public.rp_drafts set name=p_data->>'name',caption=p_data->>'caption',primary_stat=p_data->>'primary_stat',distance=p_data->>'distance',event_date=(p_data->>'event_date')::date,photo_x=(p_data->>'photo_x')::numeric,photo_y=(p_data->>'photo_y')::numeric,photo_zoom=(p_data->>'photo_zoom')::numeric,photo_id=photo,preview_id=preview,version=version+1,updated_at=now()
   where id=p_id and owner_id=uid and version=p_version and card_id=p_data->>'card_id' returning * into result;
   if not found then raise exception 'Draft changed or unavailable' using errcode='40001'; end if;
 end if;
 return result;
end $$;
create function public.rp_remove_draft(p_id uuid,p_version integer) returns void language plpgsql security definer set search_path='' as $$
begin
 if not rp_private.active() then raise exception 'Not permitted' using errcode='42501'; end if;
 perform 1 from public.rp_profiles where id=auth.uid() for update;
 if not rp_private.active() then raise exception 'Not permitted' using errcode='42501'; end if;
 delete from public.rp_drafts where owner_id=auth.uid() and id=p_id and version=p_version;
 if not found then raise exception 'Draft changed or unavailable' using errcode='40001'; end if;
end $$;
-- Only release a reservation AFTER its file is removed through Storage API.
create function public.rp_release_asset(p_id uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if not rp_private.active() then raise exception 'Not permitted' using errcode='42501'; end if;
 perform 1 from public.rp_profiles where id=auth.uid() for update;
 if not rp_private.active() then raise exception 'Not permitted' using errcode='42501'; end if;
 delete from public.rp_assets a where a.id=p_id and a.owner_id=auth.uid()
 and not exists(select 1 from public.rp_drafts d where d.photo_id=a.id or d.preview_id=a.id)
 and not exists(select 1 from storage.objects o where o.name=a.path and o.bucket_id in ('customer-photos','draft-previews'));
end $$;
create function public.rp_begin_deletion() returns void language plpgsql security definer set search_path='' as $$
begin
 if not rp_private.active() or not exists(select 1 from auth.sessions where id::text=(auth.jwt()->>'session_id') and user_id=auth.uid() and created_at>now()-interval '10 minutes') then raise exception 'Sign in again before deletion' using errcode='42501'; end if;
 update public.rp_profiles set lifecycle='deleting' where id=auth.uid();
 insert into rp_private.deletion_jobs(user_id) values(auth.uid()) on conflict do nothing;
end $$;

revoke all on function public.rp_reserve_asset(text,text,integer),public.rp_save_draft(uuid,integer,jsonb,text,text),public.rp_remove_draft(uuid,integer),public.rp_release_asset(uuid),public.rp_begin_deletion() from public,anon,authenticated;
grant execute on function public.rp_reserve_asset(text,text,integer),public.rp_save_draft(uuid,integer,jsonb,text,text),public.rp_remove_draft(uuid,integer),public.rp_release_asset(uuid),public.rp_begin_deletion() to authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
 ('customer-photos','customer-photos',false,10485760,array['image/jpeg','image/png','image/webp']),
 ('draft-previews','draft-previews',false,10485760,array['image/jpeg','image/png','image/webp']);
create function rp_private.owns_object(object_name text,bucket text) returns boolean language sql stable security definer set search_path='' as $$
 select rp_private.active() and exists(select 1 from public.rp_assets where owner_id=auth.uid() and path=object_name and ((kind='photo' and bucket='customer-photos') or(kind='preview' and bucket='draft-previews')));
$$;
revoke all on function rp_private.owns_object(text,text) from public,anon,authenticated;
grant execute on function rp_private.owns_object(text,text) to authenticated;
create policy rp_object_read on storage.objects for select to authenticated using (rp_private.owns_object(name,bucket_id));
create policy rp_object_insert on storage.objects for insert to authenticated with check (
 rp_private.owns_object(name,bucket_id) and exists(select 1 from public.rp_assets a where a.path=storage.objects.name and a.owner_id=auth.uid() and (storage.objects.metadata->>'size')::bigint<=a.byte_size)
);
-- No UPDATE policy: objects are immutable. New version = a new opaque object.
create policy rp_object_remove on storage.objects for delete to authenticated using (
 rp_private.owns_object(name,bucket_id) and not exists(select 1 from public.rp_drafts d join public.rp_assets a on a.id in (d.photo_id,d.preview_id) where a.path=storage.objects.name)
);
-- Admin-only deletion job access; no service key in browser or ordinary data paths.
create function public.rp_deletion_jobs() returns setof rp_private.deletion_jobs language sql security definer set search_path='' as $$select * from rp_private.deletion_jobs where state<>'complete'$$;
create function public.rp_deletion_status(p_user uuid,p_complete boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 update rp_private.deletion_jobs set attempts=attempts+1,state=case when p_complete then 'complete' else 'pending' end,completed_at=case when p_complete then now() else null end where user_id=p_user;
end $$;
create function public.rp_invite_email(p_email text) returns void language sql security definer set search_path='' as $$insert into rp_private.invited_emails(email) values(lower(p_email)) on conflict do nothing$$;
create function public.rp_email_invited(p_email text) returns boolean language sql security definer set search_path='' as $$select exists(select 1 from rp_private.invited_emails where email=lower(p_email))$$;
create function public.rp_revoke_invite(p_user uuid) returns void language sql security definer set search_path='' as $$delete from rp_private.invited_emails where email=(select lower(email) from auth.users where id=p_user)$$;
revoke all on function public.rp_revoke_invite(uuid) from public,anon,authenticated;
grant execute on function public.rp_revoke_invite(uuid) to service_role;
revoke all on function public.rp_deletion_jobs(),public.rp_deletion_status(uuid,boolean),public.rp_invite_email(text),public.rp_email_invited(text) from public,anon,authenticated;
grant execute on function public.rp_deletion_jobs(),public.rp_deletion_status(uuid,boolean),public.rp_invite_email(text),public.rp_email_invited(text) to service_role;
grant all on public.rp_profiles,public.rp_assets,public.rp_drafts to service_role;
commit;
