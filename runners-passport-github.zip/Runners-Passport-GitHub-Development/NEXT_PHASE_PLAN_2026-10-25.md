# Runner’s Passport — proposed next phase

25 October 2026. Recommendations for discussion, not approval to launch services or publish.

## Where we are

The current heritage website is a static prelaunch prototype. It has a catalogue, selected public artwork previews, a working browser-only personaliser, local saved drafts and album design previews. It does not have server accounts, cross-device storage, connected fitness accounts, genuine achievement calculations or checkout. Previous account/Strava screens in legacy scripts were demonstrations, not working integrations.

Keep the approved brand, actual card artwork and two-card product. Each set comprises two separate 63 × 88 mm cards, each with a shared reverse. Do not use the older blueprint’s single-card/front-and-personalised-back model or older card dimensions.

## Recommended order

### 1. Design the private My Passport experience

Build reviewable desktop and mobile screens before committing to a backend provider. Continue to label demonstration data. Account creation must lead into something useful immediately.

Main navigation inside the account: My Passport, Adventures, Achievements, Connections. Put settings and orders within the profile menu; avoid a crowded public navigation bar.

My Passport should lead with the person’s collection and next useful action, not a wall of graphs. Show saved memories, purchased pairs, eligible adventures awaiting personalisation, and a small selection of achievement progress. Maintain the warm editorial design, ivory, forest green and restrained sun details. Keep the shopping journey close to the physical album.

Design empty, populated, loading, sync-failed, disconnected, needs-review and completed states. Onboarding: create account → choose interests → optionally connect a service or add an adventure → see possible matches → confirm → personalise → later purchase/reveal.

### 2. Implement real accounts and private storage

Use managed authentication rather than designing a password system ourselves. Provisional recommendation: verified email code/link with Google as an optional later convenience. A fitness connection is separate from the Runner’s Passport login, so disconnecting a provider does not lock the customer out.

Move drafts, photos, crop settings and collection records to private storage with per-customer access controls. Offer an explicit import of existing local drafts after sign-in; do not silently associate a shared device’s drafts with the wrong account. Include verification, sign-out, expired-link handling, account recovery, export and deletion.

Keep the existing Cloudflare-hosted presentation where practical. Add a server layer and a managed relational database/auth service. Supabase is one candidate for auth/database/private storage; Cloudflare Workers can host backend endpoints. Select the final stack after reviewing access, costs and who will maintain it, rather than rebuilding the visual website for its own sake.

### 3. Build one complete activity-to-memory flow

First implement independent customer submissions and a review queue: activity details, an original activity file where suitable, or a result/proof attachment. File import may prefill distance/date/time, but is evidence rather than an automatic guarantee of participation.

Trial one approved provider integration on a small private cohort. Make sync optional. Show exactly what was found and ask for confirmation when the match is uncertain. Preserve raw-source provenance and distinguish possible matches from verified completion.

Matching uses the appropriate activity type, event year/date, distance tolerance, route evidence and title where available. Distance alone cannot establish that someone completed a named race or summit. A multi-day trail or end-to-end cycle needs a different completion rule from a single race. Prevent duplicate credit when the same workout arrives from two providers. Account for renamed, edited, deleted and late-arriving activities.

Do not promise unlimited historical imports. Connections need real consent, provider review, token handling, disconnect behaviour and sync-status/error states.

### 4. Add a small, credible achievement catalogue

Start with around 8–12 clearly defined milestones. Proposed examples:

| Milestone | Honest progress presentation |
|---|---|
| Five completed adventures | 3 of 5 eligible adventures |
| Explore all four activities | 2 of 4 categories completed |
| Three defined summits | 1 of 3 named summits |
| Walk 100 km in a chosen month | 78 of 100 km, with the date window shown |
| First half marathon | Not yet confirmed / awaiting review / achieved |
| Sub-25-minute 5K | Best eligible time 26:10; 1:10 to goal, rather than a misleading percentage |

These are proposed rules, not live achievements. Confirm whether lifetime activity before signup counts; how manual evidence counts; whether a repeated route counts once or repeatedly; and which activities/units/date windows qualify. Use only permitted data sources.

Keep these states separate: completed experience, verified evidence, achievement earned, card purchased, and artwork revealed. Recommended model: earning an achievement is free; the physical pair is an optional purchase. Completing an activity must not be presented as purchasing a card, and purchasing must not fabricate sporting achievement.

Progress bars should have a clear numerator, denominator and rule. They should be quiet visual aids with accessible text, not casino-style rewards or invented rarity. Retain the agreed Classic / Signature / Exceptional labels only under documented, activity-appropriate rules; do not extrapolate running distance tiers to hiking or cycling without agreement.

### 5. Complete purchasing, reveal and fulfilment before a public sales launch

Create a reliable whole journey: eligibility → personalisation → product preview → transparent total price → confirmed payment → artwork reveal → printing/packing/shipping. Add an operator view for proof review, orders and print files. The website should reduce the founder’s manual administration, not create an unmanageable queue of one-off requests.

Protect unrevealed artwork on the server. Payments and entitlements must be established by verified server events, never a browser flag. Check refund/chargeback states and duplicated payment notifications. Show only approved public previews before purchase. A customer chooses the exact adventure and edition; there is no random paid outcome.

Social passports come later. First decide what is independently shareable, who can see it and whether the viewer owns the same artwork edition. Keep imported provider data private unless its use is expressly permitted. Do not assume a sharing checkbox overrides provider restrictions.

## Provider findings checked today

- **Strava:** its current policy restricts disclosure to other users, AI use, processing/combination and retention. Treat our matching, milestone, printing and permanent-record uses as requiring specific confirmation; do not assume that a connection permits them. Its getting-started guide describes an initial personal testing stage and capacity review. [API policy](https://www.strava.com/legal/api_policy), [API agreement](https://www.strava.com/legal/api), [developer onboarding](https://developers.strava.com/docs/getting-started/).
- **Garmin:** the business programme offers Starter and Enterprise access. Starter’s published specification excludes historical data. Review approval and historical coverage before promising to discover previous races. [Current programme overview](https://developer.garmin.com/gc-developer-program/overview/).
- **Apple Health:** HealthKit is an Apple-platform framework. A website-only button is insufficient; plan a native companion integration or another permitted route later. [HealthKit](https://developer.apple.com/documentation/healthkit/).
- Other services need individual feasibility checks. Do not advertise Nike, adidas, Fitbit, Komoot or other connectors until official access, permitted uses and actual implementation have been established. Do not use scraping or request fitness-account passwords.

These are implementation constraints and questions for providers, not legal clearance. No provider has been contacted or application submitted in this phase.

## Technical references for the proposed foundation

- [Cloudflare Workers with static assets](https://developers.cloudflare.com/workers/static-assets/): supports adding server logic alongside the website.
- [Supabase auth users](https://supabase.com/docs/guides/auth/users): managed sign-in options.
- [Supabase private storage](https://supabase.com/docs/guides/storage/buckets/fundamentals): private objects require access rules. This is a candidate service, not a final selection.

## Copy-ready prompts for the next work

### A — design the experience first (recommended next prompt)

“Design a mobile-first My Passport prototype using our existing warm heritage identity. Include a personal collection, possible adventure matches, saved memories, achievement progress and connection settings. Keep earned, verified and purchased states distinct. Use labelled sample data; preserve my actual cards and photos; show empty and error states as well as a populated account. Keep unrevealed artwork hidden and show desktop and mobile previews before implementing real accounts. Do not publish.”

### B — build the account foundation after design approval

“Implement the approved account experience with managed authentication and private per-user storage. First propose the backend/service configuration and costs. Preserve existing personalisation, add explicit local-draft migration, support account recovery and deletion, and test that one customer cannot access another customer’s photos or drafts. Keep fitness connections separate from account login. Work in a review environment; no public deployment.”

### C — make importing trustworthy

“Prepare a provider-by-provider feasibility matrix for our priority fitness apps, covering current approval, history, permitted matching, milestone calculations, printing, sharing, retention and costs. Build one complete approved import flow with deduplication, possible-match review and manual evidence fallback. Use synthetic fixtures until access is approved; do not scrape or send prohibited provider data to AI tools.”

### D — define achievements before decorating them

“Design the first 10 Runner’s Passport achievements across running, hiking, walking and cycling. For each specify exactly what counts, historical eligibility, accepted evidence, duplicate handling, progress text, reset rules and what earns the card. Show restrained progress bars only where the measurement is meaningful. Separate free achievement recognition from optional card purchase and keep unrevealed artwork concealed.”

### E — close the commercial loop

“Build and test one complete staging journey from eligible adventure through personalisation, payment confirmation, private artwork reveal and a print-ready fulfilment record. Confirm pricing/postage first. Preserve the two-card 63 × 88 mm format, test failed/duplicate payment events and private asset access, and give me a reviewable preview before any launch.”

## Decisions requested

1. Approve My Passport screen design first, or implement accounts first? Recommendation: design the useful account destination first.
2. Which fitness apps are the actual launch priorities? Provisional recommendation: investigate Strava and Garmin in parallel, with an independent manual/file route.
3. Is achievement progress free with optional physical cards, or tied to purchases? Recommendation: free achievement recognition with optional cards.

Later decisions: beta audience size, service budget, proof standards, historical eligibility, launch date and order/production capacity. Do not turn these into blockers for the initial design prototype.
