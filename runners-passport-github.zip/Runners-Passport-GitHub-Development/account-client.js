/* Server-managed, HttpOnly sessions. No customer tokens or cloud photos in localStorage. */
(() => {
 'use strict';let user=null,generation=0;const urls=new Set(),pending=new Set();
 const channel=typeof BroadcastChannel==='function'?new BroadcastChannel('rp-account-review'):null;
 function clear(){generation++;user=null;pending.forEach(c=>c.abort());pending.clear();urls.forEach(u=>URL.revokeObjectURL(u));urls.clear();window.dispatchEvent(new Event('rp:account-cleared'));}
 channel?.addEventListener('message',()=>{clear();window.dispatchEvent(new Event('rp:account-changed'));});
 async function api(path,options={}){
  const epoch=generation,controller=new AbortController();pending.add(controller);
  const execute=async()=>{if(epoch!==generation)throw Error('Account changed. Reload before continuing.');
   const headers={...(options.body?{'Content-Type':'application/json'}:{}),...(user?{'X-RP-Account':user.id}:{}),...options.headers};
   const r=await fetch('/api/'+path,{...options,headers,signal:controller.signal,credentials:'same-origin',cache:'no-store'});
   if(epoch!==generation)throw Error('Account changed. Reload before continuing.');
   if(!r.ok){let b;try{b=await r.json();}catch{}if(r.status===401||r.status===403){clear();}const e=Error(b?.error||'Account service unavailable. Your device drafts are safe.');e.status=r.status;throw e;}
   return options.binary?await r.blob():await r.json();
  };
  try{return navigator.locks?await navigator.locks.request('rp-account-session',execute):await execute();}finally{pending.delete(controller);}
 }
 async function session(){const result=await api('session');if(user&&result.user?.id!==user.id)clear();user=result.user;return user;}
 function changed(next){clear();user=next;channel?.postMessage('changed');window.dispatchEvent(new Event('rp:account-changed'));}
 async function asData(id){if(!id)return null;const blob=await api('assets/'+id,{binary:true});return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(Error('Photo could not be read.'));r.readAsDataURL(blob);});}
 async function loadDraft(id){await session();if(!user)throw Error('Sign in to open this account draft.');const owner=user.id;const {draft}=await api('drafts/'+encodeURIComponent(id));const photo=await asData(draft.photoId);if(user?.id!==owner)throw Error('Account changed.');return {...draft,photo};}
 async function assetURL(id){const epoch=generation;const blob=await api('assets/'+id,{binary:true});if(epoch!==generation)throw Error('Account changed.');const url=URL.createObjectURL(blob);urls.add(url);return url;}
 window.RPAccount={api,session,changed,clear,loadDraft,assetURL,get user(){return user;},get generation(){return generation;}};
 window.addEventListener('pagehide',()=>{pending.forEach(c=>c.abort());urls.forEach(u=>URL.revokeObjectURL(u));urls.clear();});
 window.addEventListener('pageshow',e=>{if(e.persisted)location.reload();});
})();
