import {HttpError} from './validation.mjs';

// An admin-created, unconfirmed account needs the confirmation flow. With public
// signup disabled, signInWithOtp returns signup_disabled even for that account.
// Resend sends the existing signup token; it neither creates nor confirms users.
export async function requestEmailCode(auth,email){
 let {error}=await auth.signInWithOtp({email,options:{shouldCreateUser:false}});
 if(error?.code==='signup_disabled')({error}=await auth.resend({type:'signup',email}));
 if(error){
  if(error.status===429||error.code==='over_email_send_rate_limit'||error.code==='over_request_rate_limit')
   throw new HttpError(429,'Please wait a minute before requesting another code.');
  if(error.code==='email_address_invalid')throw new HttpError(400,'Check your email address and try again.');
  // Do not expose provider messages or claim delivery after a failed request.
  throw new HttpError(503,'We couldn’t request your sign-in email. Please try again shortly.');
 }
 return {message:'Check your inbox for your sign-in code. It may take a minute; check spam too.',retryAfter:60};
}
