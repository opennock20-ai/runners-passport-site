export class HttpError extends Error { constructor(status,message){super(message);this.status=status;} }
export function requireOrigin(request,env){
 const url=new URL(request.url), origin=env.APP_ORIGIN;
 if(!origin || url.origin!==origin)throw new HttpError(403,'Please use the correct website address.');
 if(!['GET','HEAD'].includes(request.method) && request.headers.get('origin')!==origin)throw new HttpError(403,'Please use the website to make this change.');
 if(request.headers.get('sec-fetch-site')==='cross-site')throw new HttpError(403,'Cross-site request refused.');
}
export const uuid=value=>typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
function text(v,max){if(typeof v!=='string'||!v.trim()||v.trim().length>max)throw new HttpError(400,'Please check the draft details.');return v.trim();}
function range(v,min,max,fallback){v=v??fallback;if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max)throw new HttpError(400,'Invalid photo framing.');return v;}
export function validateDraft(d){
 if(!d||typeof d!=='object'||Array.isArray(d))throw new HttpError(400,'Invalid draft.');
 const permitted=['cardId','name','caption','primary','distance','date','photoPositionX','photoPosition','photoZoom','photo','preview','id','updated'];
 if(Object.keys(d).some(k=>!permitted.includes(k)))throw new HttpError(400,'Unexpected draft fields.');
 if(!['plymouth','nevis','cycle','coast','richmond'].includes(d.cardId))throw new HttpError(400,'Unknown adventure.');
 if(typeof d.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(d.date)||d.date<'1900-01-01'||d.date>'2100-12-31'||new Date(d.date).toISOString().slice(0,10)!==d.date)throw new HttpError(400,'Please check the date.');
 return {card_id:d.cardId,name:text(d.name,50),caption:text(d.caption,60),primary_stat:text(d.primary,24),distance:text(d.distance,24),event_date:d.date,photo_x:range(d.photoPositionX,0,100,50),photo_y:range(d.photoPosition,0,100,50),photo_zoom:range(d.photoZoom,1,3,1)};
}
export function decodeImage(uri){
 if(typeof uri!=='string')throw new HttpError(400,'A preview image is required.');
 const m=/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(uri);
 if(!m||m[2].length>14*1024*1024)throw new HttpError(400,'Choose a JPEG, PNG or WebP image up to 10 MB.');
 let raw;try{raw=atob(m[2]);}catch{throw new HttpError(400,'Invalid image encoding.');}
 const b=Uint8Array.from(raw,c=>c.charCodeAt(0));
 if(!b.length||b.length>10485760)throw new HttpError(413,'Image is larger than 10 MB.');
 const jpg=b[0]===255&&b[1]===216&&b[2]===255;
 const png=[137,80,78,71,13,10,26,10].every((v,i)=>b[i]===v);
 const webp=raw.startsWith('RIFF')&&raw.slice(8,12)==='WEBP';
 if(!(m[1]==='image/jpeg'?jpg:m[1]==='image/png'?png:webp))throw new HttpError(400,'Image content does not match its type.');
 return {bytes:b,mime:m[1]};
}
export async function readJSON(request,max=16*1024*1024){
 if(!request.headers.get('content-type')?.startsWith('application/json'))throw new HttpError(415,'JSON required.');
 if(Number(request.headers.get('content-length'))>max)throw new HttpError(413,'Request too large.');
 const reader=request.body?.getReader();if(!reader)throw new HttpError(400,'Request body required.');
 let length=0,parts=[];
 try{while(true){const {value,done}=await reader.read();if(done)break;length+=value.length;if(length>max){await reader.cancel();throw new HttpError(413,'Request too large.');}parts.push(value);}}
 finally{reader.releaseLock();}
 const bytes=new Uint8Array(length);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}
 try{return JSON.parse(new TextDecoder().decode(bytes));}catch{throw new HttpError(400,'Invalid JSON.');}
}
export function requireOwner(request,id){if(request.headers.get('x-rp-account')!==id)throw new HttpError(409,'Your signed-in account changed. Reload before saving.');}
export async function fingerprint(value){const bytes=new TextEncoder().encode(JSON.stringify(value));return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');}
