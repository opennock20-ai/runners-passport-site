import {createServerClient,parseCookieHeader,serializeCookieHeader} from '@supabase/ssr';
import {createClient} from '@supabase/supabase-js';
import {HttpError,requireOrigin,readJSON,validateDraft,decodeImage,requireOwner,uuid,fingerprint} from './validation.mjs';
import {requestEmailCode} from './email-auth.mjs';
const authOptions={persistSession:false,autoRefreshToken:false,detectSessionInUrl:false};
export function adminClient(env){return createClient(env.SUPABASE_URL,env.SUPABASE_SECRET_KEY,{auth:authOptions});}
const dbError=e=>{if(e)throw new HttpError(e.code==='40001'?409:e.code==='42501'?403:400,e.code==='40001'?'This draft changed in another tab. Reload before editing.':'The change could not be saved. Check your details or photo allowance and try again.');};
export function configured(env){return env.REVIEW_ONLY==='true'&&!!env.SUPABASE_URL&&!!env.SUPABASE_PUBLISHABLE_KEY&&!!env.SUPABASE_SECRET_KEY;}
function customerClient(request,env,cookies){
 return createServerClient(env.SUPABASE_URL,env.SUPABASE_PUBLISHABLE_KEY,{
  cookieOptions:{name:'rp-review',httpOnly:true,secure:new URL(env.APP_ORIGIN).protocol==='https:',sameSite:'strict',path:'/',maxAge:7*86400},
  cookies:{getAll:()=>parseCookieHeader(request.headers.get('cookie')||''),setAll:items=>items.forEach(x=>cookies.push(serializeCookieHeader(x.name,x.value,{...x.options,httpOnly:true,secure:new URL(env.APP_ORIGIN).protocol==='https:',sameSite:'strict',path:'/'})))}
 });
}
const rowToDraft=d=>({id:d.id,cardId:d.card_id,name:d.name,caption:d.caption,primary:d.primary_stat,distance:d.distance,date:d.event_date,photoPositionX:Number(d.photo_x),photoPosition:Number(d.photo_y),photoZoom:Number(d.photo_zoom),photoId:d.photo_id,previewId:d.preview_id,version:d.version,updated:d.updated_at,legacyId:d.legacy_id,fingerprint:d.fingerprint});
async function upload(client,kind,image){
 const {data,error}=await client.rpc('rp_reserve_asset',{p_kind:kind,p_mime:image.mime,p_size:image.bytes.length});dbError(error);
 const r=Array.isArray(data)?data[0]:data;
 const {error:err}=await client.storage.from(kind==='photo'?'customer-photos':'draft-previews').upload(r.path,image.bytes,{contentType:image.mime,upsert:false,cacheControl:'0'});
 if(err){await client.rpc('rp_release_asset',{p_id:r.id});throw new HttpError(503,'Photo upload failed. Your local copy is safe; try again.');}return r;
}
async function cleanup(client,assets){
 for(const a of assets){const {data:refs,error:e}=await client.from('rp_drafts').select('id').or(`photo_id.eq.${a.id},preview_id.eq.${a.id}`).limit(1);if(e||refs.length)continue;
 const {error}=await client.storage.from(a.kind==='photo'?'customer-photos':'draft-previews').remove([a.path]);if(!error)await client.rpc('rp_release_asset',{p_id:a.id});}
}
// Re-runnable privileged worker. No request can specify an arbitrary deletion target.
export async function runDeletionJobs(env,onlyUser=null){
 const admin=adminClient(env);const {data:jobs,error}=await admin.rpc('rp_deletion_jobs');if(error)throw new Error('Deletion queue unavailable');
 const results=[];
 for(const job of jobs.filter(j=>!onlyUser||j.user_id===onlyUser)){let complete=false;try{
  const {data:assets,error:e}=await admin.from('rp_assets').select('*').eq('owner_id',job.user_id);if(e)throw e;
  for(const bucket of ['customer-photos','draft-previews']){const keys=assets.filter(a=>(a.kind==='photo')===(bucket==='customer-photos')).map(a=>a.path);for(let i=0;i<keys.length;i+=100){const {error}=await admin.storage.from(bucket).remove(keys.slice(i,i+100));if(error)throw error;}}
  // All owned objects are reserved before upload. Auth deletion cascades DB rows.
  const {error:revoke}=await admin.rpc('rp_revoke_invite',{p_user:job.user_id});if(revoke)throw revoke;
  const {error:del}=await admin.auth.admin.deleteUser(job.user_id);if(del&&del.status!==404)throw del;
  complete=true;
 }catch{/* Retry queue contains no credentials, photos or error payloads. */}
 const {error:statusError}=await admin.rpc('rp_deletion_status',{p_user:job.user_id,p_complete:complete});if(statusError)throw new Error('Deletion status unavailable');results.push({id:job.user_id,complete});}
 return results;
}
export async function handleAPI(request,env){
 const cookieChanges=[];const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'private, no-store','Vary':'Cookie','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'};
 const respond=(body,status=200)=>{const h=new Headers(headers);cookieChanges.forEach(c=>h.append('Set-Cookie',c));return new Response(JSON.stringify(body),{status,headers:h});};
 try{
  requireOrigin(request,env);
  const path=new URL(request.url).pathname;
  if(path==='/api/config'&&request.method==='GET')return respond({ready:configured(env),emailReady:env.AUTH_EMAIL_READY==='true',review:true,login:'email-code',fitness:'not-connected'});
  if(!configured(env))throw new HttpError(503,'Account services are not connected yet. Your device drafts still work.');
  if(!env.APP_ORIGIN.startsWith('https://')&&!/^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(env.APP_ORIGIN))throw new HttpError(503,'Secure review origin required.');
  const client=customerClient(request,env,cookieChanges);
  if(path==='/api/auth/code'&&request.method==='POST'){
   if(env.AUTH_EMAIL_READY!=='true')throw new HttpError(503,'Sign-in emails are temporarily unavailable. Your device drafts remain available.');
   const b=await readJSON(request,2048);const email=String(b.email||'').trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254)throw new HttpError(400,'Enter a valid email address.');
   return respond(await requestEmailCode(client.auth,email));
  }
  if(path==='/api/auth/verify'&&request.method==='POST'){
   const b=await readJSON(request,2048);if(typeof b.email!=='string'||typeof b.code!=='string'||!/^\d{6,10}$/.test(b.code))throw new HttpError(400,'Enter the code from your email.');
   const {data,error}=await client.auth.verifyOtp({email:b.email.trim().toLowerCase(),token:b.code,type:'email'});
   if(error||!data.user)throw new HttpError(400,'That code is invalid or expired. Request a new code.');
   const {data:profile}=await client.from('rp_profiles').select('id,display_name').eq('id',data.user.id).maybeSingle();
   if(!profile){await client.auth.signOut({scope:'local'});throw new HttpError(403,'This account is currently unavailable.');}
   return respond({user:{id:data.user.id,email:data.user.email,name:profile.display_name}});
  }
  const {data:{user},error:authError}=await client.auth.getUser();
  if(authError||!user){if(path==='/api/session')return respond({user:null});throw new HttpError(401,'Please sign in again. Your device drafts are safe.');}
  const {data:profile,error:profileError}=await client.from('rp_profiles').select('id,display_name').eq('id',user.id).maybeSingle();
  if(profileError||!profile)throw new HttpError(403,'This account is unavailable or being deleted.');
  if(path==='/api/session'&&request.method==='GET')return respond({user:{id:user.id,email:user.email,name:profile.display_name}});
  // Bind every authenticated request, including downloads, to the account the UI expects.
  requireOwner(request,user.id);
  if(path==='/api/auth/logout'&&request.method==='POST'){
   const b=await readJSON(request,1024);const {error}=await client.auth.signOut({scope:b.all===true?'global':'local'});if(error)throw new HttpError(503,'Sign out could not be confirmed. Please try again.');return respond({signedOut:true});
  }
  if(path==='/api/account'&&request.method==='DELETE'){
   const b=await readJSON(request,1024);if(b.confirm!=='DELETE')throw new HttpError(400,'Type DELETE to confirm.');
   const {error}=await client.rpc('rp_begin_deletion');if(error)throw new HttpError(403,'For your security, sign in with a fresh email code before deleting your account.');
   // Immediately revoked by lifecycle RLS, even if provider/global signout is delayed.
   await client.auth.signOut({scope:'global'});
   let complete=false;try{complete=(await runDeletionJobs(env,user.id)).some(j=>j.id===user.id&&j.complete);}catch{}
   if(complete)return respond({deleted:true,message:'Your account and private files have been removed from the active service. Provider backups follow their retention policy. Independent device drafts and downloads remain on your device.'});
   return respond({deletionRequested:true,message:'Your account is locked and deletion has been requested. File removal is retried until complete. Separate device drafts and downloaded files are not deleted.'},202);
  }
  if(path==='/api/profile'&&request.method==='PATCH'){
   const b=await readJSON(request,1024);if(typeof b.name!=='string'||b.name.trim().length>60)throw new HttpError(400,'Use a name up to 60 characters.');
   const {error}=await client.from('rp_profiles').update({display_name:b.name.trim()}).eq('id',user.id);dbError(error);return respond({saved:true});
  }
  if(path==='/api/drafts'&&request.method==='GET'){const {data,error}=await client.from('rp_drafts').select('*').order('updated_at',{ascending:false});dbError(error);return respond({drafts:data.map(rowToDraft)});}
  if(path==='/api/drafts'&&request.method==='POST'){
   const b=await readJSON(request);const d=validateDraft(b.draft);
   if(b.id!=null&&(!uuid(b.id)||!Number.isInteger(b.version)||b.version<1))throw new HttpError(400,'Invalid draft version.');
   if(b.legacyId!=null&&(typeof b.legacyId!=='string'||b.legacyId.length>120||!b.legacyId||b.id))throw new HttpError(400,'Invalid migration.');
   const key=b.legacyId?await fingerprint(b.draft):null;
   if(key){const {data,error}=await client.from('rp_drafts').select('*').eq('legacy_id',b.legacyId).eq('fingerprint',key).maybeSingle();dbError(error);if(data)return respond({draft:rowToDraft(data),alreadyCopied:true});}
   const preview=decodeImage(b.draft.preview),photo=b.draft.photo?decodeImage(b.draft.photo):null;
   let old=[];
   if(b.id){const {data,error}=await client.from('rp_drafts').select('*').eq('id',b.id).maybeSingle();dbError(error);if(!data||data.version!==b.version)throw new HttpError(409,'This draft changed or is unavailable. Reload before editing.');const r=await client.from('rp_assets').select('*').in('id',[data.photo_id,data.preview_id].filter(Boolean));dbError(r.error);old=r.data;}
   const added=[];try{
    let p=null;if(photo){p=await upload(client,'photo',photo);added.push(p);}const v=await upload(client,'preview',preview);added.push(v);
    const {data,error}=await client.rpc('rp_save_draft',{p_id:b.id||null,p_version:b.version||null,p_data:{...d,photo_id:p?.id||null,preview_id:v.id},p_legacy:b.legacyId||null,p_fingerprint:key});dbError(error);
    const row=Array.isArray(data)?data[0]:data;
    await cleanup(client,[...old,...added]);return respond({draft:rowToDraft(row)},201);
   }catch(e){await cleanup(client,added);throw e;}
  }
  const draftMatch=/^\/api\/drafts\/([a-f0-9-]+)$/.exec(path);
  if(draftMatch&&uuid(draftMatch[1])){
   const {data:d,error}=await client.from('rp_drafts').select('*').eq('id',draftMatch[1]).maybeSingle();dbError(error);if(!d)throw new HttpError(404,'Draft not found.');
   if(request.method==='GET')return respond({draft:rowToDraft(d)});
   if(request.method==='DELETE'){const b=await readJSON(request,1024);const {data:a,error:e}=await client.from('rp_assets').select('*').in('id',[d.photo_id,d.preview_id].filter(Boolean));dbError(e);const {error}=await client.rpc('rp_remove_draft',{p_id:d.id,p_version:b.version});dbError(error);await cleanup(client,a);return respond({deleted:true});}
  }
  const assetMatch=/^\/api\/assets\/([a-f0-9-]+)$/.exec(path);
  if(assetMatch&&uuid(assetMatch[1])&&request.method==='GET'){
   const {data:a,error}=await client.from('rp_assets').select('*').eq('id',assetMatch[1]).maybeSingle();dbError(error);if(!a)throw new HttpError(404,'Photo not found.');
   const {data,error:e}=await client.storage.from(a.kind==='photo'?'customer-photos':'draft-previews').download(a.path);if(e)throw new HttpError(404,'Photo not found.');
   const h=new Headers({...headers,'Content-Type':a.mime,'Content-Disposition':'inline','Content-Security-Policy':"default-src 'none'; sandbox"});cookieChanges.forEach(c=>h.append('Set-Cookie',c));return new Response(data,{headers:h});
  }
  throw new HttpError(404,'Account endpoint not found.');
 }catch(e){return respond({error:e instanceof HttpError?e.message:'The account service could not complete this request. Please try again.'},e instanceof HttpError?e.status:503);}
}
export default {fetch:handleAPI};
