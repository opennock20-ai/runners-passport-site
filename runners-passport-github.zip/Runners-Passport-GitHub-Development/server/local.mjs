import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,sep,extname} from 'node:path';
import {Readable} from 'node:stream';
import {handleAPI,runDeletionJobs,configured} from './api.mjs';
const port=Number(process.env.PORT||8893), origin=process.env.APP_ORIGIN||`http://127.0.0.1:${port}`;
const env={...process.env,APP_ORIGIN:origin}, root=resolve('dist');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.txt':'text/plain','.woff2':'font/woff2'};
let cleaning=false;async function reap(){if(!configured(env)||cleaning)return;cleaning=true;try{await runDeletionJobs(env);}catch{}finally{cleaning=false;}}
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,origin);
  if(req.headers.host!==new URL(origin).host){res.writeHead(403);return res.end('Invalid host');}
  if(url.pathname.startsWith('/api/')){
   const init={method:req.method,headers:req.headers};if(!['GET','HEAD'].includes(req.method)){init.body=Readable.toWeb(req);init.duplex='half';}
   const result=await handleAPI(new Request(url,init),env);
   res.writeHead(result.status,{...Object.fromEntries([...result.headers].filter(([k])=>k!=='set-cookie')),'set-cookie':result.headers.getSetCookie()});
   return res.end(Buffer.from(await result.arrayBuffer()));
  }
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end();}
  const path=resolve(root,'.'+decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname));
  if(!path.startsWith(root+sep)||!types[extname(path)]){res.writeHead(404);return res.end('Not found');}
  if(!(await stat(path)).isFile())throw Error();
  res.writeHead(200,{'Content-Type':types[extname(path)],'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'SAMEORIGIN','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; frame-src 'self' about:; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'"});
  res.end(req.method==='HEAD'?undefined:await readFile(path));
 }catch{if(!res.headersSent)res.writeHead(404);res.end('Not found');}
});
server.listen(port,'127.0.0.1',()=>console.log(`Private local account review: ${origin}/account.html\nBackend: ${configured(env)?'configured — live isolation tests still required':'not configured — device drafts and design review available'}\nServing dist/ only. No deployment.`));
setInterval(reap,60000).unref();
