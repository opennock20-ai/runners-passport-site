# Heritage preview assets

Prepared 25 October 2026. Existing artwork is retained; website assets are resized WebP derivatives. No new lifestyle or physical-product photography has been generated. Sophie images and achievements are fictional demonstration content. The album is a design prototype, not a manufactured sample. These must be reviewed against the latest physical prototype photographs before publication.

- assets/heritage/cycle-art.webp from CARD DESIGN/Four adventures prototype 01/cycle-art.png
- assets/heritage/cycle-memory.webp from CARD DESIGN/Four adventures prototype 01/cycle-memory.png
- assets/heritage/cycle-photo.webp from CARD DESIGN/Four adventures prototype 01/cycle-photo.png
- assets/heritage/cycle-footer.webp from CARD DESIGN/Four adventures prototype 01/cycle-footer.png
- assets/heritage/nevis-art.webp from CARD DESIGN/Four adventures prototype 01/hike-art.png
- assets/heritage/nevis-memory.webp from CARD DESIGN/Four adventures prototype 01/hike-memory.png
- assets/heritage/nevis-photo.webp from CARD DESIGN/Four adventures prototype 01/hike-photo.png
- assets/heritage/nevis-footer.webp from CARD DESIGN/Four adventures prototype 01/hike-footer.png
- assets/heritage/coast-art.webp from CARD DESIGN/Four adventures prototype 01/walk-art.png
- assets/heritage/coast-memory.webp from CARD DESIGN/Four adventures prototype 01/walk-memory.png
- assets/heritage/coast-photo.webp from CARD DESIGN/Four adventures prototype 01/walk-photo.png
- assets/heritage/coast-footer.webp from CARD DESIGN/Four adventures prototype 01/walk-footer.png
- assets/heritage/richmond-art.webp from CARD DESIGN/Four adventures prototype 01/run-art.png
- assets/heritage/richmond-memory.webp from CARD DESIGN/Four adventures prototype 01/run-memory.png
- assets/heritage/richmond-photo.webp from CARD DESIGN/Four adventures prototype 01/run-photo.png
- assets/heritage/richmond-footer.webp from CARD DESIGN/Four adventures prototype 01/run-footer.png
- assets/heritage/plymouth-art.webp from CARD DESIGN/Plymouth personalisation 02/plymouth-art.png
- assets/heritage/plymouth-memory.webp from CARD DESIGN/Plymouth personalisation 02/plymouth-memory.png
- assets/heritage/plymouth-photo.webp from CARD DESIGN/Plymouth personalisation 02/plymouth-photo.png
- assets/heritage/plymouth-footer.webp from CARD DESIGN/Plymouth personalisation 02/plymouth-footer.png
- assets/heritage/album-cover.webp from ALBUM DESIGN/Supplier pack 02/front-cover-flat.png
- assets/heritage/album-spread.webp from ALBUM DESIGN/Interior prototype 06/collection-preview.png
- assets/heritage/album-opening.webp from ALBUM DESIGN/Interior prototype 06/opening-preview.png
- assets/heritage/memory-base.webp from CARD DESIGN/Four adventures prototype 01/memory-base.png
- assets/heritage/landscape.webp from ALBUM DESIGN/Interior prototype 06/landscape-footer.png

Plymouth personalisation was explicitly rebuilt on the Four adventures template on 25 October. Its existing photograph, caption, 17 May 2026 date, 1:56:18 time and 21.1 km distance were retained. The existing artwork front was extracted unchanged. Its older printed tier/logo treatment remains visible and is not a newly approved tier master.

Symbol: BRAND/Production master 01/symbol-colour.svg. Album cover: Supplier pack 02. Album interior: Interior prototype 06. Consult their existing source and production records; this register is not a new rights clearance.

## Discovery revision — 25 October 2026

- card-reverse.webp: existing approved BRAND/Production master 01/revision-06/navy-back.png, resized without altering its design.
- album-bookshelf.webp: existing ALBUM DESIGN/Spine prototype 01/bookshelf-spine.png. AI-created design concept, not a photograph of a manufactured album.
- Album interior now renders the existing Interior prototype 06 HTML layout with exact card files, a subtle light overlay, page gutter shadows and pocket reflections. It is a lighting study, not physical photography. Opening pair is Plymouth; collection shows Plymouth, Ben Nevis and End to End, with two card reverses filling the reserved pair.
- Old album screenshot spreads and Richmond/Coast to Coast artwork were moved to ../Reserved artwork - not public/. They are absent from the web root and build output. The earlier inventory above records provenance, not current public availability.
- No new raster artwork or image-generation prompts used in this revision. Existing product artwork, photos and logos were not redesigned.
