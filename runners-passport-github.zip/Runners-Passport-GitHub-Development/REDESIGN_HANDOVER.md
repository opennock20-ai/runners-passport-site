# Runner’s Passport — heritage prelaunch preview

Local redesign branch: codex/heritage-prelaunch.
Base: 8e6d4f9c3b071b18dde2536618f167a6726fb2c6.
Prepared 25 October 2026. Not pushed or deployed.

## Agreed direction
- Polished prelaunch first; navigation and personalisation before account/Strava integration.
- Warm ivory, forest green, muted sage and restrained terracotta.
- Real two-card pair as the central product. Album introduced immediately after the hero and given its own page.
- Featured designs: End to End / Land’s End–John o’ Groats, Plymouth and Ben Nevis.
- Running, hiking, walking and cycling in one collection.
- Founder confirmed printing, lamination, corner rounding, checking and packing. Copy uses precise hand-finishing wording.

## Implemented
Eight consistent static pages: homepage, catalogue, album, how it works, personalisation, saved drafts, preview privacy information and a compatibility page for the old studio URL.

Catalogue: five example adventures, four activity filters, search, empty state, accessible modal pair views and deep links.

Personalisation: existing approved layout proportions, activity-specific details, caption/date editing, local image selection and photo position, preview export. Save draft stores the personal details, a resized photograph and thumbnail in the browser. Reopen and edit on this device. No purchase is taken and nothing is uploaded.

Album: latest Supplier pack 02 cover proportions and Interior prototype 06 spread views, with opening/collection switch. Manufacturing remains unconfirmed.

Plymouth memory card: rebuilt using the Four adventures template in CARD DESIGN/Plymouth personalisation 02. Existing photo, caption and example statistics retained. Old artwork front retained, including its historic tier/logo treatment; no permission was inferred to change that artwork.

## Build and preview
Requires Node 18+ for the static build. There are no package dependencies for the website itself.

    node scripts/make-pages.mjs
    node scripts/check-site.mjs
    node build.mjs

The development copy was served on http://127.0.0.1:8892/ using Python’s local HTTP server. Use an HTTP server rather than file:// for reliable canvas export and draft storage across pages. Preview serves only on loopback.

Generated HTML is committed source; scripts/make-pages.mjs is the page authoring source. heritage.css, heritage.js and data.js are shared. The build includes only current heritage assets. Legacy implementation files remain in the source checkout for reference but are not built.

Asset preparation is a local authoring tool using the user's established artwork folder and the bundled Sharp runtime. It is not needed to build or host this static site. See ASSET_REGISTER.md.

## Verification
- JavaScript syntax checks passed.
- Static checks passed: 8 pages, 195 local link/image/script references, all expected card assets, 4 categories, noindex tags.
- Static distribution build passed.
- Browser: desktop 1440 × 1000 and mobile 390 × 844 reviewed.
- No horizontal overflow detected in the reviewed homepage viewports.
- Mobile navigation opened and catalogue navigation worked.
- Hiking filter returned Ben Nevis; search Plymouth returned only Plymouth.
- Pair modal showed both cards and the appropriate personalisation link.
- Caption changes appeared in the accessible live preview.
- Saved draft reopened with edited caption and the selected local sample photograph.
- PNG preview export succeeded.
- Album opening-spread switch loaded its correct image.
- No JavaScript console errors in the tested paths.
- Not an exhaustive accessibility or cross-browser certification. Network loading, real payment, activity verification and fulfilment have not been tested as production systems.

Proofs are saved in ../proofs. A fictional Plymouth test draft may remain in the local preview browser and a test export in Downloads.

## Before publication
- User design approval.
- Replace design mock-ups with the latest real physical-prototype photography supplied by the user; existing Sophie imagery is explicitly fictional.
- Confirm Plymouth event naming: the current artwork is 13.1 miles / 21.1 km, not a marathon.
- Decide whether Plymouth’s older artwork tier/logo also needs the newer master treatment.
- Confirm card/album pricing, postage and album manufacturing details.
- Connect a real consent-based launch signup service if desired. No fake email-capture flow has been added.
- Future accounts, digital passport, achievements, Strava, payment, order storage and fulfilment remain unimplemented and are described accordingly.
- Resolve live-domain Cloudflare 522 / deployment mapping separately before release.
- Keep prelaunch noindex until explicitly ready to launch.


## Discovery, reverse and framing revision — 25 October 2026

Public-preview allowlist: cycle, plymouth, nevis. Richmond and Coast to Coast list metadata and show the shared navy reverse; no blur overlays over their original images. Reserved artwork and old album screenshots are outside the served source directory and excluded from dist. Checkout, verification and purchase-authorised reveals remain future work; a static client flag is not access control. Production must serve reserved assets through server-authorised purchase entitlements. Friends' digital passports are still a future feature.

The homepage and How it works clarify the two-card set and shared reverse. Pair dialogs toggle both fronts/reverses. The catalogue explains the selected-preview policy without random paid outcomes. Brand terracotta sun circles replace decorative bullet separators.

Draft grey fragments fixed by making the thumbnail link a block and removing its fragmented inline background. Existing user drafts retained. Photo zoom 100–300% added, works with vertical crop, resets with new/sample photos, and persists per draft. Legacy drafts default to 100%. Photos remain local.

Album left hinge and right page edges corrected. Existing bookshelf concept added. Interior uses the approved layout as exact HTML with subtle light and pocket reflections; no fictional product photography claim. It is embedded via srcdoc so the existing X-Frame-Options: DENY header is preserved.

Validation: syntax, local references, three-preview allowlist, no reserved artwork in web root, mobile 390px overflow check, reverse toggle, concealed modal, saved-draft visual inspection, zoom boundaries and save/reload (180% zoom and 100 vertical position) using a separate localhost origin so real 127.0.0.1 drafts remain untouched. Test-only QA draft remains on localhost, not the user's preview origin. No deployment.

Scripts refine-discovery.cjs, prepare-discovery.cjs and finalise-discovery.cjs are one-time migration records, not build steps. Use node scripts/make-pages.mjs, node scripts/check-site.mjs, then node build.mjs. Do not rerun the old prepare-heritage-assets utility without honouring the public-preview allowlist.

## Direct photo framing — 25 October 2026
Replaced the vertical slider with photo-only direct dragging in both axes. A single zoom slider and Reset framing sit beneath the card, so the photograph and controls remain together on mobile. Reset framing retains the selected photograph; Use the sample photograph is separate. Drag bounds prevent blank areas. Pointer events support mouse and touch; keyboard arrow keys move the image, Shift increases the step. Page scrolling stays enabled outside the photograph.
Saved drafts now include photoPositionX alongside legacy photoPosition and photoZoom. Older drafts default to horizontal centre, preserving their previous vertical crop and zoom. Card export uses the same crop geometry as the preview. Switching to artwork hides crop controls.
Validation: actual diagonal mouse drag, keyboard arrows, save/reload on isolated QA origin, reset and 390px mobile visual review; JavaScript syntax, site-reference checks and static build passed. No production deployment or user-draft edits. refine-photo-framing.cjs is a one-time migration record, not a build step.

## Hero detail and interior light — 25 October 2026
Removed the sun from “For the days that stay with you”; added it immediately before Running in the activity list. Replaced identical diagonal pocket glare with low-opacity, varied edge reflections and a broad diffuse highlight. Updated source template, regenerated pages and passed site checks/build. No deployment.
The proposed next phase is in NEXT_PHASE_PLAN_2026-10-25.md. This records current integration constraints, an account/achievement design sequence and copy-ready prompts. It is a proposal awaiting the user's direction; no auth service, provider connection or paid infrastructure has been provisioned.

## My Passport design preview — 25 October 2026
Approved direction: design the member experience before real accounts; prioritise Strava and Garmin subject to provider permissions; free earned progress with optional card purchases and non-preview artwork concealed until purchase.
Added my-passport.html, authored via passport-preview-content.html, passport-preview.css and passport-preview.js through scripts/make-pages.mjs. Global navigation links to the preview; existing passport.html remains the untouched local saved-drafts experience.
Includes established collector/new member switch, four sections, activity filters, memory detail dialogs and editor links, three representative achievements with rules and accessible progress, uncertain Richmond match demo with progress update, concealed card state, and planned Strava/Garmin/manual/recovery screens. Fictional sample data is in memory only and resets on reload. No account, OAuth, upload, payment, verification or storage writes were added.
Validation: 9-page link/asset and reserved-art checks, JS syntax and build passed. Browser checked desktop, 390px requested mobile viewport (375px content width, no horizontal overflow), new-member zero progress, walking empty state, match confirmation 3→4 of 5, and section navigation. Proofs: my-passport-desktop.png and my-passport-new-mobile.png. Not deployed.

## My Passport prototype refinement — earned / verified / purchased
Expanded the existing local design preview to five sections: Passport, Adventures, Memories, Achievements, Connections. All member data remains labelled fictional and in memory; no persistent writes, auth, network integration or payment was introduced. Existing card/photo files and saved drafts were not edited.
Separate Experience, Evidence and Physical pair statuses appear on adventure cards and detail dialogs. Richmond is visible initially as a possible match using only the navy card reverse. Recording the match moves earned count 3→4 while verified count stays 3 and purchases stay 2. Explicitly previewing evidence approval moves verified count to 4; artwork remains concealed. Dismissal does not delete an activity and supports undo from the overview.
Memories section shows existing fictional photos with editable sample captions (maximum 60 characters, trim/validation and escaped rendering). Sample edits reset on reload and do not regenerate or overwrite card artwork. Connection previews support demo connect, settings, disconnect, import interruption/retry and expired-permission states. View-as selector includes new member and account-unavailable error with recovery.
QA: actual browser interactions verified pending→approved state counts, concealed Richmond image source, sample caption save, demo connect/import-error/retry, zero progress and empty memories. Desktop at 1280px and mobile at 390px requested viewport (375px content) reviewed; no horizontal overflow. Syntax, 9-page references, reserved-art checks and static build pass. Proofs: my-passport-v2-desktop.png, my-passport-v2-mobile.png. No publishing or real account implementation.
