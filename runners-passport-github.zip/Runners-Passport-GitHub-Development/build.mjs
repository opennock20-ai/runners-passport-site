import {cp,copyFile,mkdir,readFile,rm,stat} from 'node:fs/promises';
import {join,resolve,sep,basename} from 'node:path';
const root=resolve('.'), out=resolve(root,'dist');
if(!out.startsWith(root+sep)||basename(out)!=='dist')throw new Error('Unexpected build target');
await rm(out,{recursive:true,force:true});
await mkdir(out,{recursive:true});
for(const name of ['account-album.css','account-album.js'])await copyFile(join(root,name),join(out,name));
for(const name of ['index.html','collection.html','album.html','album-preview.html','how-it-works.html','personalise.html','passport.html','my-passport.html','account.html','account.css','account.js','account-client.js','account-editor.js','passport-preview.css','passport-preview.js','privacy.html','studio.html','heritage.css','heritage.js','data.js','robots.txt','_headers']){
  await copyFile(join(root,name),join(out,name));
}
// A sitemap is unnecessary for the explicitly blocked pre-launch preview.
// Require one once search indexing is enabled, rather than silently omitting it.
const sitemap=join(root,'sitemap.xml');
let hasSitemap=false;
try{hasSitemap=(await stat(sitemap)).isFile();}catch(error){if(error.code!=='ENOENT')throw error;}
if(hasSitemap)await copyFile(sitemap,join(out,'sitemap.xml'));
else{
  const robots=await readFile(join(root,'robots.txt'),'utf8');
  if(!/^Disallow:\s*\/\s*$/m.test(robots))throw new Error('Public build requires a sitemap.xml.');
  console.log('Pre-launch: sitemap.xml absent; indexing remains blocked.');
}
await mkdir(join(out,'assets'),{recursive:true});
await cp(join(root,'assets','heritage'),join(out,'assets','heritage'),{recursive:true});
for(const name of ['coast-art.webp','richmond-art.webp','album-spread.webp','album-opening.webp','coast-memory.webp','richmond-memory.webp'])await rm(join(out,'assets','heritage',name),{force:true});
console.log('Runner\'s Passport static site ready at dist/');
