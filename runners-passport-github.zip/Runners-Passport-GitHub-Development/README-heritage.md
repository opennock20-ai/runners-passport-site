# Runner's Passport — Heritage prelaunch preview

A local redesign of the existing site, prepared 25 October 2026 on branch codex/heritage-prelaunch. **Not deployed.**

See [REDESIGN_HANDOVER.md](REDESIGN_HANDOVER.md) for scope, browser checks and remaining launch decisions, and [ASSET_REGISTER.md](ASSET_REGISTER.md) for image provenance.

## Current experience

- Homepage centred on illustrated artwork and personal memory pairs.
- One searchable catalogue with running, hiking, walking and cycling filters.
- Five sample adventures, with the chosen End to End, Plymouth and Ben Nevis designs featured.
- Album page based on the latest supplier brief, with opening/collection spread views.
- Live personalisation preview, local image selection, save/reopen drafts and PNG preview export.
- Explicit prelaunch status: no payment, order submission, login, real activity verification or email signup.

Photos and personalisation remain in the browser. Saving a draft retains details and a resized photo in local browser storage. This is not a production order workflow.

## Build

Requires Node 18+; no dependency install is needed.

    node scripts/make-pages.mjs
    node scripts/check-site.mjs
    node build.mjs

The build outputs dist/. Only the new pages, shared scripts/styles and heritage assets are included. Older implementation files remain in this source checkout for reference.

## Preview

Serve this directory or dist/ through a local HTTP server. The reviewed preview used:

    python -m http.server 8892 --bind 127.0.0.1

Then open http://127.0.0.1:8892/. Do not rely on file:// for canvas exports or cross-page draft storage.

The page generator is scripts/make-pages.mjs. Shared styling is heritage.css; interactions are heritage.js; sample adventure records are data.js. The local asset preparation script is an authoring utility and is not needed by the deployment build.

## Hosting and publication

The supplied repository is opennock20-ai/runners-passport-site. Its previous configuration describes Cloudflare Pages, with build command npm run build and output dist. GitHub Pages was disabled at the time of the audit.

Do not push or deploy this redesign without the user's approval. Keep noindex and robots exclusions during prelaunch review. The live domain returned Cloudflare 522 during the audit; confirm its hosting/deployment mapping before release.

