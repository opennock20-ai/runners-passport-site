// Creates an invited account without sending mail. The reviewer proves mailbox
// access through the site's OTP flow. No passwords are generated or printed.
import {createInterface} from 'node:readline/promises';
import {adminClient} from '../server/api.mjs';
if(process.env.REVIEW_ONLY!=='true'||!process.env.SUPABASE_SECRET_KEY)throw Error('Configure the isolated review environment first.');
const rl=createInterface({input:process.stdin,output:process.stdout});
const email=(await rl.question('Email of the reviewer you are inviting: ')).trim().toLowerCase();rl.close();
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('Invalid email');
const admin=adminClient(process.env);const {error}=await admin.rpc('rp_invite_email',{p_email:email});if(error)throw Error('Could not add review invitation. Check migration.');
const created=await admin.auth.admin.createUser({email,email_confirm:false});
if(created.error)throw Error('Could not create reviewer. If already present, the invitation is now updated.');
console.log('Reviewer created. No email sent. They can request a code on the local account page.');
