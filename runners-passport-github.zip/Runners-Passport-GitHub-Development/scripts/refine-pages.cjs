const fs=require('fs');
const file='scripts/make-pages.mjs';
let source=fs.readFileSync(file,'utf8');
source=source.replace('beside you.<br>Collect','beside you. <br>Collect');
source=source.replace('<section class="section shell" id="collection">','<aside class="album-introduction shell"><img src="assets/heritage/album-cover.webp" alt="Proposed album cover" loading="lazy"><div><p class="eyebrow">A HOME FOR THE WHOLE COLLECTION</p><p>A passport you’ll fill for years.</p></div><a class="text-link" href="album.html">Meet the album ↗</a></aside><section class="section shell" id="collection">');
fs.writeFileSync(file,source);
