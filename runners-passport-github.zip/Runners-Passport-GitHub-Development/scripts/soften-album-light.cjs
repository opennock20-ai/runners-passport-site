// One-time visual refinement; the normal authoring command remains make-pages.mjs.
const fs=require('fs');
let maker=fs.readFileSync('scripts/make-pages.mjs','utf8');
maker=maker.replace('<span class="sun-dot"></span> FOR THE DAYS THAT STAY WITH YOU','FOR THE DAYS THAT STAY WITH YOU');
maker=maker.replace('<p class="hero-activities">RUNNING','<p class="hero-activities"><span class="brand-sun activity-leading-sun" aria-hidden="true"></span>RUNNING');
maker=maker.replaceAll('20261025-framing','20261025-light');
fs.writeFileSync('scripts/make-pages.mjs',maker);
let album=fs.readFileSync('album-preview.html','utf8');
album=album.replace('</style><main>',`</style><style>
/* Broad window light and small, uneven edge reflections, without repeated glossy stripes. */
.album:after{background:radial-gradient(ellipse at 12% 8%,#fff8e512 0%,transparent 63%)}
.pocket:after{background:none;border-top:1px solid #ffffff75;border-right:1px solid #ffffff30}
.page:first-of-type .pocket:first-child:after{background:radial-gradient(ellipse at 8% 0%,#ffffff14,transparent 65%)}
.page:first-of-type .pocket:nth-child(3):after{border-top-color:#ffffff40;border-right-color:#ffffff16}
.page:last-of-type .pocket:nth-child(2):after{background:radial-gradient(ellipse at 100% 10%,#ffffff0a,transparent 55%);border-right-color:#ffffff48}
.page:last-of-type .pocket:nth-child(4):after{border-top-color:#ffffff25;border-right-color:#ffffff14}
</style><main>`);
fs.writeFileSync('album-preview.html',album);
fs.appendFileSync('heritage.css','\n.hero-activities .activity-leading-sun{margin-left:0;margin-right:8px}\n');
console.log('Moved the hero sun and softened repeated album reflections.');
