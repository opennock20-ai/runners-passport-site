import {readFile,access,stat} from 'node:fs/promises';
import {join} from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const pages=['index','collection','album','how-it-works','personalise','passport','my-passport','account','privacy','studio'];
let references=0;
for(const page of pages){
 const html=await readFile(page+'.html','utf8');
 assert.match(html,/<html lang="en-GB">/);assert.equal((html.match(/<h1[\s>]/g)||[]).length,1,page+' should have one h1');
 assert.match(html,/noindex,nofollow/);assert.match(html,/heritage.js/);
 const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]));
 for(const m of html.matchAll(/(?:href|src)="([^"]+)"/g)){
  const url=m[1];if(/^(https?:|data:|mailto:)/.test(url))continue;
  const [local,hash]=url.split('#');const pathname=local.split('?')[0];
  if(!pathname){if(hash)assert(ids.has(hash),'Missing anchor '+url+' in '+page);continue;}
  await access(pathname);
  if(hash&&pathname.endsWith('.html')){const destination=await readFile(pathname,'utf8');assert(destination.includes('id="'+hash+'"'),'Missing destination anchor '+url);}
  references++;
 }
}
const context={window:{}};vm.runInNewContext(await readFile('data.js','utf8'),context);const cards=context.window.RP_CARDS;
assert.equal(cards.length,5);assert.equal(new Set(cards.map(c=>c.category)).size,4);
assert.equal(cards.find(c=>c.id==='plymouth').distance,'21.1 km');
assert.equal(cards.filter(c=>c.publicPreview).length,3);
for(const c of cards){
 for(const kind of (c.publicPreview?['art','memory','photo','footer']:['photo','footer']))
  assert((await stat(join('assets','heritage',c.id+'-'+kind+'.webp'))).size>1000);
 if(!c.publicPreview)for(const kind of ['art','memory']){
  let exists=false;
  try{await access(join('assets','heritage',c.id+'-'+kind+'.webp'));exists=true;}
  catch(error){if(error.code!=='ENOENT')throw error;}
  assert(!exists,'Concealed artwork/memory must not be in the public source assets: '+c.id+'-'+kind);
 }
}
for(const name of ['coast-art.webp','richmond-art.webp','coast-memory.webp','richmond-memory.webp','album-spread.webp','album-opening.webp']){let exists=false;try{await access(join('assets','heritage',name));exists=true;}catch{}assert(!exists,'Reserved imagery should be outside the web root: '+name);}
const spread=await readFile('album-preview.html','utf8');
assert(!/src="[^\"]*(?:coast|richmond)-(?:art|memory)/.test(spread),'Album must not disclose reserved designs');
for(const m of spread.matchAll(/src="([^"]+)"/g))await access(m[1]);
console.log('PASS: '+pages.length+' pages, '+references+' local links/assets, 5 adventures across 4 activities, 3 public pairs, concealed assets outside web root, curated album spread.');

