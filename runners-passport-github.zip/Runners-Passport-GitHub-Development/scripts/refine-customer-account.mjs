import {readFile,writeFile} from 'node:fs/promises';
const edits={
 'scripts/make-pages.mjs':[
 ['A PRELAUNCH PREVIEW','COLLECT THE ADVENTURES YOU’VE EARNED'],
 ['My Passport · private account review','My Passport'],
 ['Try personalising a pair','Personalise your pair'],
 ['PERSONALISATION PREVIEW · NO PURCHASE','YOUR MEMORY, MADE PERSONAL'],
 ['These are the first design previews.','Discover the first collection.'],
 ['Not yet. This is a prelaunch preview of the first designs. You can explore the cards, try personalisation and save a draft on this device. No payment is taken.','Ordering opens soon. For now, explore the cards, personalise your pair and save it to your passport. No payment is taken.'],
 ['Not for this preview. Strava integration, activity verification, accounts and a digital passport are future features. They are not connected or verifying activities here.','No. Sign in with your email and save your memories to your passport. Strava and Garmin connections are coming later, with your permission.'],
 ['In the private account review, only an explicit account save or selected migration uploads a private copy.','Only choosing Save to my account or Copy selected drafts uploads a private copy.'],
 ['You can download a personalisation preview and save drafts on this device. This is not yet an account or a synchronised digital passport.','Yes. Sign in to save private memories and turn through them in your digital passport. You can also keep separate drafts on this device and download a card preview.'],
 ['account review address','My Passport'],
 ['How this preview works','How your memories are saved'],
 ['In the private account review, choosing','Choosing'],
 ['This design preview requests','This website requests'],
 ['has been added to this preview','is connected'],
 ['Private account review','Your private account'],
 ['Invited testers can use email-code login','Sign in with an email code'],
 ['This review is not open for public customer use.','Ordering has not opened yet.'],
 ['Design preview. No purchase or activity verification is available yet.','Ordering and activity verification are coming soon. Save your personalised pair for now.'],
 ['planned features, not live in this preview','coming later; they are not available yet']
 ],
 'account-content.html':[
 ['<button data-account-view="memories" aria-current="page">Saved memories <span>01</span></button><button data-account-view="collection">My collection <span>02</span></button>','<button data-account-view="collection" aria-current="page">My album <span>01</span></button><button data-account-view="memories">Saved memories <span>02</span></button>']
 ],
 'account.js':[
 ['No local drafts were found at this website address. Drafts saved at a different localhost address or port are separate.','There are no saved drafts on this device yet.'],
 ['Achievement tracking will be free, with physical cards optional. Activity imports and verification are not enabled yet, so there is no invented progress in your account.\',\'my-passport.html?view=achievements\',\'Explore labelled sample achievements','Achievement tracking is coming soon. Your progress will be free to follow, with physical cards an optional way to celebrate.'],
 ['NOT CONNECTED · PLANNED','COMING SOON'],
 ['Provider approval and a separate permission step are still required. No fitness credentials or activities are collected in this review.','Connect your activities here when the integration is ready. You will always choose what to share.'],
 ['Changing your email is not available in this review.','Email changes are not available yet.']
 ],
 'account-editor.js':[['Account saving will be available after review setup. Device drafts still work.','Account saving is temporarily unavailable. You can still save on this device.']],
 'server/api.mjs':[
 ['Sign-in email setup is still being verified. Your device drafts remain available.','Sign-in emails are temporarily unavailable. Your device drafts remain available.'],
 ['This account is not available for this review.','This account is currently unavailable.']
 ],
 'server/validation.mjs':[
 ['This review origin is not allowed.','Please use the correct website address.'],
 ['Please use the review website to make this change.','Please use the website to make this change.']
 ],
 'tests/account-unit.test.mjs':[['/still being verified/','/temporarily unavailable/']]
};
for(const [file,replacements] of Object.entries(edits)){let text=await readFile(file,'utf8');for(const [from,to] of replacements){if(!text.includes(from))throw Error('Missing replacement in '+file+': '+from);text=text.replaceAll(from,to);}await writeFile(file,text);}
