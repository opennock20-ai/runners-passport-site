const fs=require('fs'),path=require('path');
const sharp=require('C:/Users/openn/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const project=path.resolve(__dirname,'..'), workspace=path.resolve(__dirname,'../../../..'), out=path.join(project,'assets/heritage');
const adventure='CARD DESIGN/Four adventures prototype 01', plymouth='CARD DESIGN/Plymouth personalisation 02';
const sources={};
for(const [id,key] of [['cycle','cycle'],['nevis','hike'],['coast','walk'],['richmond','run']]){
 for(const part of ['art','memory','photo','footer'])sources[id+'-'+part]=[adventure+'/'+key+'-'+part+'.png',part==='footer'?1200:part==='photo'?1200:1100];
}
for(const part of ['art','memory','photo','footer'])sources['plymouth-'+part]=[plymouth+'/plymouth-'+part+'.png',part==='footer'?1200:1100];
Object.assign(sources,{'album-cover':['ALBUM DESIGN/Supplier pack 02/front-cover-flat.png',1000],'album-spread':['ALBUM DESIGN/Interior prototype 06/collection-preview.png',1500],'album-opening':['ALBUM DESIGN/Interior prototype 06/opening-preview.png',1500],'memory-base':[adventure+'/memory-base.png',1061],'landscape':['ALBUM DESIGN/Interior prototype 06/landscape-footer.png',1800]});
(async()=>{fs.mkdirSync(out,{recursive:true});for(const [name,[file,width]]of Object.entries(sources)){await sharp(path.join(workspace,file)).resize({width,withoutEnlargement:true}).webp({quality:92}).toFile(path.join(out,name+'.webp'));}
 fs.copyFileSync(path.join(workspace,'BRAND/Production master 01/symbol-colour.svg'),path.join(out,'symbol.svg'));
 fs.writeFileSync(path.join(project,'ASSET_REGISTER.md'),'# Heritage preview assets\n\nPrepared 25 October 2026. Existing artwork is retained; website assets are resized WebP derivatives. No new lifestyle or physical-product photography has been generated. Sophie images and achievements are fictional demonstration content. The album is a design prototype, not a manufactured sample. These must be reviewed against the latest physical prototype photographs before publication.\n\n'+Object.entries(sources).map(([name,[file]])=>'- assets/heritage/'+name+'.webp from '+file).join('\n')+'\n\nPlymouth personalisation was explicitly rebuilt on the Four adventures template on 25 October. Its existing photograph, caption, 17 May 2026 date, 1:56:18 time and 21.1 km distance were retained. The existing artwork front was extracted unchanged. Its older printed tier/logo treatment remains visible and is not a newly approved tier master.\n\nSymbol: BRAND/Production master 01/symbol-colour.svg. Album cover: Supplier pack 02. Album interior: Interior prototype 06. Consult their existing source and production records; this register is not a new rights clearance.\n');
 console.log('Prepared '+Object.keys(sources).length+' web images and existing brand symbol.');
})();
