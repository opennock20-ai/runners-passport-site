const fs=require('fs'),path=require('path');
const sharp=require('C:/Users/openn/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const root='C:/Users/openn/OneDrive/Documents/ChatGPT/Running passport';
let js=fs.readFileSync('heritage.js','utf8').replaceAll("')\"><", "')+'\"><").replaceAll("')\" loading", "')+'\" loading");fs.writeFileSync('heritage.js',js);
(async()=>{
 await sharp(path.join(root,'BRAND/Production master 01/revision-06/navy-back.png')).resize({width:850}).webp({quality:90}).toFile('assets/heritage/card-reverse.webp');
 await sharp(path.join(root,'ALBUM DESIGN/Spine prototype 01/bookshelf-spine.png')).resize({width:1500,withoutEnlargement:true}).webp({quality:88}).toFile('assets/heritage/album-bookshelf.webp');
 // Preserve the approved HTML album layout and exact card artwork. No resampling a screenshot.
 let html=fs.readFileSync(path.join(root,'ALBUM DESIGN/Interior prototype 06/index.html'),'utf8');
 html=html.replace(/<title>.*?<\/title>/,'<title>Album interior design mock-up</title><meta name="robots" content="noindex,nofollow">');
 const map={'run-art.png':'plymouth-art.webp','run-memory.png':'plymouth-memory.webp','hike-art.png':'nevis-art.webp','hike-memory.png':'nevis-memory.webp','cycle-art.png':'cycle-art.webp','cycle-memory.png':'cycle-memory.webp','walk-art.png':'card-reverse.webp','walk-memory.png':'card-reverse.webp','landscape-footer.png':'landscape.webp','landscape-symbol.svg':'symbol.svg'};
 for(const [a,b]of Object.entries(map))html=html.replaceAll(a,'assets/heritage/'+b);
 html=html.replaceAll('alt="run art card"','alt="Plymouth artwork card"').replaceAll('alt="run memory card"','alt="Plymouth memory card"').replaceAll('alt="walk art card"','alt="Concealed illustration, card reverse shown"').replaceAll('alt="walk memory card"','alt="Matching card reverse"');
 html=html.replace(/<main>.*?(<section id="opening")/s,'<main>$1');
 html=html.replace(/<p class="notes">.*?<\/p>/gs,'');
 html=html.replace(/<script>.*?<\/script>/s,`<script>const opening=new URLSearchParams(location.search).get('spread')==='opening';document.getElementById('opening').hidden=!opening;document.getElementById('collection').hidden=opening;</script>`);
 // Decorative stationary proof, not a second editable form inside the webpage.
 html=html.replaceAll('<input aria-label','<input readonly tabindex="-1" aria-label').replace('<textarea aria-label','<textarea readonly tabindex="-1" aria-label');
 html=html.replace('</style><main>',`</style><style>
 body{background:transparent;overflow:hidden}main{max-width:none;padding:4.5% 4% 8%}.scroll{padding:0;overflow:visible}.album{min-width:0;padding:1%;border-radius:5px;transform:perspective(1800px) rotateX(5deg) rotateZ(-1deg);box-shadow:0 16px 22px #27392f35,0 3px 0 #d5ccba,0 6px 0 #2c4435}.page{aspect-ratio:180/250}.continuous-landscape{inset:1%;background:#f4eee2}.album:after{content:'';position:absolute;inset:1%;z-index:4;pointer-events:none;background:linear-gradient(115deg,#fff9df27 0%,transparent 38%,#19302307 100%)}.page:first-of-type{border-right:5px solid #c6bead;box-shadow:inset -18px 0 19px -12px #6b5c4440}.page:last-of-type{border-left:5px solid #d6ccba;box-shadow:inset 20px 0 19px -13px #6b5c4438}.pocket{padding:3px;box-shadow:0 0 0 2px #f5f0e6,0 0 0 3px #b29c766b,1px 3px 5px #28382d20}.pocket:after{background:linear-gradient(118deg,transparent 32%,#ffffff16 43%,#ffffff32 45%,#ffffff08 53%,transparent 67%);border-top:1px solid #ffffffba;border-right:1px solid #ffffff6b}.pocket img{border-radius:3%;height:auto}.identity-kicker,.write-field span{font-size:clamp(4px,1vw,12px)}.write-field input{height:clamp(10px,3vw,35px)}.identity-motto{font-size:clamp(5px,1.3vw,16px)}.opening-title{font-size:clamp(5px,1.1vw,13px)}.story-note span{font-size:clamp(4px,1vw,12px)}.story-note textarea{height:clamp(15px,5vw,56px);background:repeating-linear-gradient(to bottom,transparent 0,transparent calc(2.5vw - 1px),#a7a08870 calc(2.5vw - 1px),#a7a08870 2.5vw)}.page footer{font-size:clamp(4px,1.1vw,12px)}
 </style><main>`);
 fs.writeFileSync('album-preview.html',html);
 let build=fs.readFileSync('build.mjs','utf8');build=build.replace("'album.html','how-it-works.html'","'album.html','album-preview.html','how-it-works.html'");
 // Hidden designs and old spreads must not be shipped in the public static build.
 build=build.replace("console.log('Runner",`for(const name of ['coast-art.webp','richmond-art.webp','album-spread.webp','album-opening.webp','coast-memory.webp','richmond-memory.webp'])await rm(join(out,'assets','heritage',name),{force:true});\nconsole.log('Runner`);
 fs.writeFileSync('build.mjs',build);
 console.log('Prepared accurate card reverse, existing bookshelf concept and native album lighting study.');
})();
