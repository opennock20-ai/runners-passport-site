# Runner's Passport - private development workspace

This repository is a snapshot of the website source provided on 27 October 2026, incorporating the Step 1 build and link-check fixes. It is NOT the published site.

## Rules

- Keep this repository **PRIVATE**. It contains pre-launch implementation and design work.
- Do not enable GitHub Pages for this repository.
- Do not connect this repository to an existing Cloudflare Pages project.
- Never add `.dev.vars`, `review.env`, service role keys, SMTP secrets, or other credentials to Git.
- Do not assume the backend works merely because the automated checks pass. Those tests exercise local logic only; no live Supabase or SMTP tests are run in GitHub Actions.
- `main` in this private repository is a development branch, **not** the production branch on the separate public repository.
- The build output is the `dist/` folder; it is deliberately ignored by Git and is not deployed by the workflow.

## Continuous integration

`.github/workflows/validate.yml` runs automatically for pushes and pull requests. It installs Node.js and dependencies on a GitHub-hosted runner, checks references and concealed artwork rules, builds the static site, and runs local account unit tests. It has no deployment step, and it does not need secrets.

## Browser-only editing

Use GitHub's web editor or open the repository in a GitHub Codespace (subject to your GitHub plan's allowances) to edit files without installing Node.js locally. Changes can be reviewed in pull requests. Codespaces are optional.

## Next manual QA

Live account testing still requires the authorised private environment and a safe backend environment. Do not place credentials in files tracked by Git.
