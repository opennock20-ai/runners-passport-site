(() => {
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const cards=window.RP_CARDS||[], A='assets/heritage/', STORAGE='rp_heritage_drafts_v1';
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const imagePath=(id,part)=>A+id+'-'+part+'.webp';
let storageError=false,toastTimer;
function readDrafts(){try{const value=JSON.parse(localStorage.getItem(STORAGE)||'[]');if(!Array.isArray(value))throw Error();return value.filter(d=>d&&typeof d.id==='string'&&cards.some(c=>c.id===d.cardId)&&typeof d.caption==='string'&&typeof d.preview==='string');}catch{storageError=true;return [];}}
function writeDrafts(value){try{localStorage.setItem(STORAGE,JSON.stringify(value));storageError=false;updateCount();return true;}catch{return false;}}
function updateCount(){$$('.draft-count').forEach(e=>e.textContent=String(readDrafts().length));}
function toast(message){$('.toast').textContent=message;$('.toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('.toast').classList.remove('visible'),4500);}
updateCount();
const menu=$('.menu-toggle'),mobile=$('#mobile-nav');
function closeMenu(){menu?.setAttribute('aria-expanded','false');menu?.setAttribute('aria-label','Open menu');if(mobile)mobile.hidden=true;}
menu?.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Close menu':'Open menu');mobile.hidden=!open;});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!mobile?.hidden){closeMenu();menu.focus();}});
mobile?.addEventListener('click',e=>{if(e.target.closest('a'))closeMenu();});
window.addEventListener('resize',()=>{if(window.innerWidth>800)closeMenu();});
const dialog=$('#pair-dialog');let dialogOrigin;
function showPair(id,origin){const c=cards.find(x=>x.id===id);if(!c)return;dialogOrigin=origin;$('#pair-title').textContent=c.name;$('#pair-category').textContent=c.category+' / '+c.place;$('#pair-description').textContent=c.description;$('#pair-personalise').href=c.publicPreview?'personalise.html?card='+c.id:'how-it-works.html#reveal';$('#pair-personalise').textContent=c.publicPreview?'Try personalising a pair ↗':'How the reveal will work ↗';$('#pair-description').textContent=c.publicPreview?c.description:'The adventure is yours to choose. The illustration stays a surprise until purchase. This is a planned launch experience; orders and reveals are not live yet.';
$('#dialog-images').innerHTML='<div class="card-pair"><figure><img src="'+(c.publicPreview?imagePath(c.id,'art'):A+'card-reverse.webp')+'" alt="'+escape(c.name)+(c.publicPreview?' artwork card':' concealed artwork, showing the card reverse')+'"></figure><figure><img src="'+(c.publicPreview?imagePath(c.id,'memory'):A+'card-reverse.webp')+'" alt="'+escape(c.name)+(c.publicPreview?' matching memory card, fictional example':' matching card reverse')+'"></figure></div>';$('#pair-reverse-toggle').hidden=!c.publicPreview;$('#pair-reverse-toggle').dataset.card=c.id;$('#pair-reverse-toggle').setAttribute('aria-pressed','false');$('#pair-reverse-toggle').textContent='See the reverse of both cards';dialog.showModal();document.body.style.overflow='hidden';}
$('#pair-reverse-toggle')?.addEventListener('click',()=>{const b=$('#pair-reverse-toggle'),reverse=b.getAttribute('aria-pressed')!=='true';b.setAttribute('aria-pressed',String(reverse));b.textContent=reverse?'See the two card fronts':'See the reverse of both cards';$$('#dialog-images img').forEach((im,i)=>{im.src=reverse?A+'card-reverse.webp':imagePath(b.dataset.card,i?'memory':'art');im.alt=reverse?'Shared navy patterned reverse of card '+(i+1):i?'Personalised memory card':'Illustrated artwork card';});});
 document.addEventListener('click',e=>{const trigger=e.target.closest('[data-pair]');if(trigger)showPair(trigger.dataset.pair,trigger);});
$('.dialog-close')?.addEventListener('click',()=>dialog.close());
dialog?.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
dialog?.addEventListener('close',()=>{document.body.style.overflow='';dialogOrigin?.focus();});
const params=new URLSearchParams(location.search);
if($('#catalogue-grid')){
 let filter=['Running','Hiking','Walking','Cycling'].includes(params.get('activity'))?params.get('activity'):'All';
 const search=$('#adventure-search');search.value=params.get('q')||'';
 function renderCatalogue(){const q=search.value.trim().toLocaleLowerCase('en-GB');const results=cards.filter(c=>(filter==='All'||c.category===filter)&&[c.name,c.category,c.place,c.detail].join(' ').toLocaleLowerCase('en-GB').includes(q));
 $('#catalogue-grid').innerHTML=results.map(c=>'<article class="collection-card"><button class="card-window" data-pair="'+c.id+'" aria-label="View '+escape(c.name)+' matching card pair"><img src="'+(c.publicPreview?imagePath(c.id,'art'):A+'card-reverse.webp')+'" alt="'+escape(c.name)+(c.publicPreview?' artwork card':' card reverse; artwork reserved for purchase')+'" loading="lazy" decoding="async"><span class="view-pair">'+(c.publicPreview?'Preview the pair':'Discover this adventure')+' <span aria-hidden="true">↗</span></span></button><div class="card-meta"><p class="eyebrow">'+c.category+' <span class="preview-status">'+(c.publicPreview?'Open preview':'Art kept for the reveal')+'</span></p><h3><button data-pair="'+c.id+'">'+escape(c.short)+'</button></h3><p>'+escape(c.detail)+'</p></div></article>').join('');
 $('#result-count').textContent=results.length+' adventure'+(results.length===1?'':'s')+' in the first collection';$('#empty-search').hidden=results.length>0;
 $$('[data-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.filter===filter)));
 const url=new URL(location.href);if(filter==='All')url.searchParams.delete('activity');else url.searchParams.set('activity',filter);if(q)url.searchParams.set('q',search.value);else url.searchParams.delete('q');history.replaceState(null,'',url);
 }
 $$('[data-filter]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;renderCatalogue();}));
 search.addEventListener('input',renderCatalogue);$('#reset-search').addEventListener('click',()=>{filter='All';search.value='';renderCatalogue();search.focus();});renderCatalogue();
 if(params.has('card'))showPair(params.get('card'));
}
$$('[data-spread]').forEach(b=>b.addEventListener('click',()=>{const opening=b.dataset.spread==='opening';$('#album-spread').srcdoc=$('#album-spread').srcdoc.replace(/data-spread="(?:opening|collection)"/,'data-spread="'+(opening?'opening':'collection')+'"');$('#album-spread').title=opening?'Opening spread design mock-up':'Collection spread design mock-up';$('#spread-caption').textContent=opening?'A beginning in your own handwriting, beside the first pair in your collection. Design mock-up; subject to sampling.':'Warm ivory pages, fine frames and subtle pocket reflections. Design mock-up; subject to sampling.';$$('[data-spread]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));}));
function loadImage(src){return new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>reject(new Error('The image could not be loaded.'));image.src=src;});}
function formattedDate(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return 'Your date';return new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'}).format(new Date(value+'T12:00:00Z'));}
if($('#personaliser-form'))initPersonaliser().catch(()=>{$('#form-error').textContent='The preview could not load. Refresh the page and try again.';$('#save-draft').disabled=true;$('#download-preview').disabled=true;});
async function initPersonaliser(){
 const drafts=readDrafts(), cloudId=params.get('cloud');
 const existing=cloudId?await window.RPAccount.loadDraft(cloudId):drafts.find(d=>d.id===params.get('draft'));let c=cards.find(x=>x.id===(existing?.cardId||params.get('card')))||cards[0], draftId=existing?.id||null;
 const input={name:$('#draft-name'),caption:$('#memory-caption'),primary:$('#memory-stat'),distance:$('#memory-distance'),date:$('#memory-date')};
 const canvas=$('#memory-canvas'),ctx=canvas.getContext('2d'),error=$('#form-error');
 const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
 let photoPositionX=clamp(Number(existing?.photoPositionX??50)||0,0,100);
 let photoUri=existing?.photo||null,photoPosition=Math.max(0,Math.min(100,Number(existing?.photoPosition??50))),photoZoom=Math.max(1,Math.min(3,Number(existing?.photoZoom)||1)),renderTicket=0,photoVersion=0;
 $('#personaliser-category').textContent=c.category+' / '+c.place;$('#personaliser-title').textContent=c.name;
 $('#personaliser-art').src=c.publicPreview?imagePath(c.id,'art'):A+'card-reverse.webp';$('#personaliser-art').alt=c.publicPreview?c.name+' artwork card':'Artwork reserved for the purchase reveal; card reverse shown';if(!c.publicPreview)$('#toggle-preview').textContent='See card reverse';
 $('#stat-label').textContent=c.primaryLabel;$('#distance-label').textContent=c.detailLabel;$('#date-label').textContent=c.dateLabel;
 for(const [key,el]of Object.entries(input))el.value=key==='name'?(existing?.name||''):(existing?.[key]??c[key]);
 $('#photo-zoom').value=Math.round(photoZoom*100);$('#zoom-value').textContent=Math.round(photoZoom*100)+'%';
 if(storageError)error.textContent='Saved drafts cannot be read in this browser. You can still download a preview.';
 $('#save-draft').disabled=true;$('#download-preview').disabled=true;
 const [base,footer,sample]=await Promise.all([loadImage(A+'memory-base.webp'),loadImage(imagePath(c.id,'footer')),loadImage(imagePath(c.id,'photo'))]);
 let invalidated=false;window.addEventListener('rp:account-cleared',()=>{if(cloudId){invalidated=true;photoUri=null;photoVersion++;cancelAnimationFrame(renderTicket);ctx.clearRect(0,0,1061,1483);}});
 let photo=sample;if(photoUri){try{photo=await loadImage(photoUri);}catch{photoUri=null;error.textContent='The saved photo could not load. Please choose it again.';}}
 function fitText(text,x,y,size,maxWidth,font='Georgia',align='left'){ctx.fillStyle='#091831';ctx.textAlign=align;ctx.textBaseline='alphabetic';ctx.font=size+'px '+font;while(ctx.measureText(text).width>maxWidth&&size>14){size-=1;ctx.font=size+'px '+font;}ctx.fillText(text,x,y);}
 function photoGeometry(){const w=988,h=584,scale=Math.max(w/photo.width,h/photo.height)*photoZoom;return {w,h,dw:photo.width*scale,dh:photo.height*scale};}
 function drawPhoto(){const x=37,y=80,{w,h,dw,dh}=photoGeometry();ctx.save();ctx.beginPath();ctx.roundRect(x,y,w,h,12);ctx.clip();ctx.drawImage(photo,x-(dw-w)*(photoPositionX/100),y-(dh-h)*(photoPosition/100),dw,dh);ctx.restore();}
 function draw(){
 if(invalidated){ctx.clearRect(0,0,1061,1483);return;}
 ctx.clearRect(0,0,1061,1483);ctx.drawImage(base,0,0,1061,1483);drawPhoto();
 fitText(c.title,55,61,54,730);fitText(c.code,1006,61,40,230,'"Times New Roman"','right');
 fitText(input.caption.value||'Your words, your memory.',530.5,756,55,920,'"Segoe Print", cursive','center');
 ctx.strokeStyle='#AA8952';ctx.lineWidth=1.7;ctx.beginPath();ctx.moveTo(65,796);ctx.lineTo(996,796);ctx.stroke();
 fitText(c.primaryLabel.toUpperCase(),65,885,31,610);fitText(input.primary.value||'—',65,975,72.8,610);
 fitText(c.dateLabel.toUpperCase(),65,1063,30.45,320);fitText(formattedDate(input.date.value),65,1123,48.16,320);
 fitText(c.detailLabel.toUpperCase(),410,1063,27.3,270);fitText(input.distance.value||'—',410,1123,43.68,270);
 const layer=document.createElement('canvas');layer.width=1061;layer.height=283;const l=layer.getContext('2d');const scale=Math.max(1061/footer.width,283/footer.height);const w=footer.width*scale,h=footer.height*scale;l.drawImage(footer,(1061-w)/2,283-h,w,h);l.globalCompositeOperation='destination-in';const fade=l.createLinearGradient(0,0,0,71);fade.addColorStop(0,'rgba(0,0,0,0)');fade.addColorStop(1,'rgba(0,0,0,1)');l.fillStyle=fade;l.fillRect(0,0,1061,283);ctx.drawImage(layer,0,1200);
 canvas.setAttribute('aria-label',c.name+' memory preview. '+input.caption.value+'. '+c.primaryLabel+': '+input.primary.value+'. '+formattedDate(input.date.value)+'. '+input.distance.value);
 }
 function queueDraw(){cancelAnimationFrame(renderTicket);renderTicket=requestAnimationFrame(draw);}
 Object.values(input).forEach(el=>el.addEventListener('input',queueDraw));
 $('#photo-zoom').addEventListener('input',()=>{photoZoom=Number($('#photo-zoom').value)/100;$('#zoom-value').textContent=Math.round(photoZoom*100)+'%';queueDraw();});
 const dragSurface=$('#photo-drag');let drag=null;
 function endDrag(){drag=null;dragSurface.classList.remove('dragging');}
 function movePhoto(dx,dy,initialX=photoPositionX,initialY=photoPosition){const g=photoGeometry();if(g.dw-g.w>0.01)photoPositionX=clamp(initialX-dx/(g.dw-g.w)*100,0,100);if(g.dh-g.h>0.01)photoPosition=clamp(initialY-dy/(g.dh-g.h)*100,0,100);queueDraw();}
 dragSurface.addEventListener('pointerdown',e=>{if(!e.isPrimary||e.button!==0)return;e.preventDefault();dragSurface.focus({preventScroll:true});drag={id:e.pointerId,x:e.clientX,y:e.clientY,initialX:photoPositionX,initialY:photoPosition};dragSurface.setPointerCapture(e.pointerId);dragSurface.classList.add('dragging');});
 dragSurface.addEventListener('pointermove',e=>{if(!drag||e.pointerId!==drag.id)return;const unit=1061/canvas.getBoundingClientRect().width;movePhoto((e.clientX-drag.x)*unit,(e.clientY-drag.y)*unit,drag.initialX,drag.initialY);});
 dragSurface.addEventListener('pointerup',e=>{if(drag?.id===e.pointerId){if(dragSurface.hasPointerCapture(e.pointerId))dragSurface.releasePointerCapture(e.pointerId);endDrag();}});
 dragSurface.addEventListener('pointercancel',endDrag);dragSurface.addEventListener('lostpointercapture',endDrag);
 dragSurface.addEventListener('keydown',e=>{const moves={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]},d=moves[e.key];if(!d)return;e.preventDefault();const step=e.shiftKey?45:12;movePhoto(d[0]*step,d[1]*step);});
 function resetFraming(){endDrag();photoPositionX=50;photoPosition=50;photoZoom=1;$('#photo-zoom').value=100;$('#zoom-value').textContent='100%';draw();}
 $('#reset-framing').addEventListener('click',resetFraming);
 $('#photo-upload').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;const version=++photoVersion;error.textContent='';
 if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>10*1024*1024){error.textContent='Please choose a JPEG, PNG or WebP photo smaller than 10 MB.';e.target.value='';return;}
 const objectUrl=URL.createObjectURL(file);
 try{const original=await loadImage(objectUrl);if(version!==photoVersion)return;const temporary=document.createElement('canvas');const ratio=Math.min(1,1200/Math.max(original.width,original.height));temporary.width=Math.round(original.width*ratio);temporary.height=Math.round(original.height*ratio);temporary.getContext('2d').drawImage(original,0,0,temporary.width,temporary.height);const resized=temporary.toDataURL('image/jpeg',.88);const decoded=await loadImage(resized);if(version!==photoVersion)return;photo=decoded;photoUri=resized;resetFraming();}
 catch{error.textContent='This photograph could not be opened. Try a different JPEG or PNG.';}finally{URL.revokeObjectURL(objectUrl);}
 });
 $('#reset-photo').addEventListener('click',()=>{photoVersion++;photo=sample;photoUri=null;$('#photo-upload').value='';resetFraming();});
 $('#toggle-preview').addEventListener('click',()=>{const artwork=$('#personaliser-art'),show=artwork.hidden;artwork.hidden=!show;canvas.hidden=show;dragSurface.hidden=show;$('#photo-framing').hidden=show;endDrag();$('#toggle-preview').textContent=show?'See your memory':c.publicPreview?'See artwork':'See card reverse';$('#toggle-preview').setAttribute('aria-pressed',String(show));});
 $('#personaliser-form').addEventListener('submit',e=>{e.preventDefault();if(cloudId){error.textContent='Choose Save to my account to update this private draft.';return;}error.textContent='';draw();const values=Object.fromEntries(Object.entries(input).map(([key,el])=>[key,el.value.trim()]));if(!values.caption||!values.primary||!values.distance||!values.date){error.textContent='Please complete the memory, date and activity details.';return;}
 const current=readDrafts();if(storageError){error.textContent='Draft storage is unavailable. Download your preview instead.';return;}if(!draftId&&current.length>=12){error.textContent='You have 12 saved drafts. Download a preview or remove an older draft to make room.';return;}
 const id=draftId||('draft-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7));const previewCanvas=document.createElement('canvas');previewCanvas.width=424;previewCanvas.height=593;previewCanvas.getContext('2d').drawImage(canvas,0,0,424,593);
 const record={id,cardId:c.id,...values,name:values.name||c.short+' memory',photo:photoUri,photoPosition,photoPositionX,photoZoom,preview:previewCanvas.toDataURL('image/jpeg',.85),updated:Date.now()};
 const next=current.filter(d=>d.id!==id);next.unshift(record);
 if(writeDrafts(next)){draftId=id;history.replaceState(null,'','personalise.html?card='+c.id+'&draft='+encodeURIComponent(id));toast('Saved on this device. Find it in Saved drafts.');$('#save-draft').innerHTML='Update saved draft <span aria-hidden="true">↗</span>';}
 else error.textContent='Your browser has no space for this draft. Download a preview, or remove another saved draft.';
 });
 $('#download-preview').addEventListener('click',()=>{draw();canvas.toBlob(blob=>{if(!blob){error.textContent='The preview could not be exported.';return;}const uri=URL.createObjectURL(blob),a=document.createElement('a');a.href=uri;a.download='runners-passport-'+c.id+'-memory-preview.png';a.click();setTimeout(()=>URL.revokeObjectURL(uri),1500);},'image/png');});
 window.RP_EDITOR={version:existing?.version||null,snapshot:()=>{if(invalidated)throw Error('Account changed. Reopen this draft.');draw();const values=Object.fromEntries(Object.entries(input).map(([key,el])=>[key,el.value.trim()]));const small=document.createElement('canvas');small.width=424;small.height=593;small.getContext('2d').drawImage(canvas,0,0,424,593);return {cardId:c.id,...values,name:values.name||c.short+' memory',photo:photoUri,photoPosition,photoPositionX,photoZoom,preview:small.toDataURL('image/jpeg',.85)};}};
 window.dispatchEvent(new Event('rp:editor-ready'));
 draw();$('#save-draft').disabled=false;$('#download-preview').disabled=false;
 if(existing)$('#save-draft').innerHTML='Update saved draft <span aria-hidden="true">↗</span>';
}
if($('#draft-grid')){
 function renderDrafts(){const drafts=readDrafts();$('#empty-drafts').hidden=drafts.length>0;$('#draft-grid').innerHTML=drafts.map(d=>{const c=cards.find(x=>x.id===d.cardId);const safePreview=/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(d.preview)?d.preview:imagePath(c.id,'memory');return '<article class="draft-card"><a class="draft-preview" href="personalise.html?card='+c.id+'&draft='+encodeURIComponent(d.id)+'"><img src="'+safePreview+'" alt="'+escape(d.name)+' memory preview"></a><h2>'+escape(d.name)+'</h2><p>'+escape(c.name)+' · '+escape(c.category)+'</p><div class="draft-actions"><a class="text-link" href="personalise.html?card='+c.id+'&draft='+encodeURIComponent(d.id)+'">Continue editing ↗</a><button class="text-link remove-draft" data-remove="'+escape(d.id)+'">Remove</button></div></article>';}).join('');if(storageError)$('.storage-note').textContent='Draft storage is unavailable in this browser. You can still make and download a personalisation preview.';}
 $('#draft-grid').addEventListener('click',e=>{const b=e.target.closest('[data-remove]');if(!b)return;if(!confirm('Remove this draft from this browser? Download it first if you want to keep a copy.'))return;const next=readDrafts().filter(d=>d.id!==b.dataset.remove);if(writeDrafts(next)){renderDrafts();toast('Draft removed from this device.');}else toast('The draft could not be removed.');});renderDrafts();
}
})();
