import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {requireOrigin,requireOwner,decodeImage,validateDraft,readJSON,fingerprint} from '../server/validation.mjs';
import {handleAPI} from '../server/api.mjs';
const origin='http://127.0.0.1:8893';
const draft={cardId:'nevis',name:'A day above the clouds',caption:'At last.',primary:'7h',distance:'1,345 m',date:'2026-06-20'};
test('Origin check rejects cross-site, missing origin, and alternate host mutations',()=>{
 for(const o of ['https://evil.example','null',null])assert.throws(()=>requireOrigin(new Request(origin+'/api/drafts',{method:'POST',headers:o?{origin:o}:{}}),{APP_ORIGIN:origin}));
 assert.throws(()=>requireOrigin(new Request('http://localhost:8893/api/session'),{APP_ORIGIN:origin}));
 assert.doesNotThrow(()=>requireOrigin(new Request(origin+'/api/drafts',{method:'POST',headers:{origin}}),{APP_ORIGIN:origin}));
});
test('A pending write cannot silently follow an account switch',()=>{
 assert.throws(()=>requireOwner(new Request(origin,{headers:{'x-rp-account':'customer-a'}}),'customer-b'));
 assert.throws(()=>requireOwner(new Request(origin),'customer-a'));
});
test('Draft validation excludes entitlements and privilege fields; preserves legacy crop defaults',()=>{
 assert.equal(validateDraft(draft).photo_x,50);assert.equal(validateDraft(draft).photo_zoom,1);
 for(const extra of ['owner_id','verified','purchased','role'])assert.throws(()=>validateDraft({...draft,[extra]:true}));
 for(const patch of [{photoZoom:0},{photoPositionX:Infinity},{date:'2026-02-30'},{caption:'x'.repeat(61)},{cardId:'arbitrary'}])assert.throws(()=>validateDraft({...draft,...patch}));
});
test('Image inputs reject SVG, URL fetches, MIME spoofing and invalid base64',()=>{
 for(const value of ['https://example.com/photo.jpg','data:image/svg+xml;base64,PHN2Zz4=','data:image/jpeg;base64,PHNjcmlwdD4=','data:image/png;base64,%%%'])assert.throws(()=>decodeImage(value));
 assert.equal(decodeImage('data:image/jpeg;base64,/9j/2Q==').bytes.length,4);
});
test('Request length is enforced while streaming, not only via declared Content-Length',async()=>{
 await assert.rejects(readJSON(new Request(origin,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({x:'a'.repeat(100)})}),30));
});
test('Migration fingerprints distinguish content changes and remain stable on retry',async()=>{
 assert.equal(await fingerprint(draft),await fingerprint(JSON.parse(JSON.stringify(draft))));assert.notEqual(await fingerprint(draft),await fingerprint({...draft,caption:'A different day.'}));
});
test('Unconfigured review fails closed and leaks no environment secrets',async()=>{
 const env={APP_ORIGIN:origin,REVIEW_ONLY:'true',SUPABASE_SECRET_KEY:'test-private-marker'};
 const config=await handleAPI(new Request(origin+'/api/config'),env);assert.equal((await config.json()).ready,false);
 const save=await handleAPI(new Request(origin+'/api/drafts',{method:'POST',headers:{origin,'content-type':'application/json'},body:'{}'}),env);assert.equal(save.status,503);assert.match(save.headers.get('cache-control'),/no-store/);assert(!JSON.stringify(await save.json()).includes('test-private-marker'));
});
test('Static build excludes backend, migrations, env and privileged keys',async()=>{
 const entries=await readdir('dist');for(const name of ['server','supabase','tests','.dev.vars','.env','node_modules'])assert(!entries.includes(name));
 for(const file of entries.filter(x=>/\.(js|html)$/.test(x))){const s=await readFile(join('dist',file),'utf8');assert(!s.includes('SUPABASE_SECRET_KEY'),file);assert(!s.includes('service_role'),file);}
});

test('Connected database does not imply verified sign-in email',async()=>{
 const env={APP_ORIGIN:origin,REVIEW_ONLY:'true',SUPABASE_URL:'https://example.supabase.co',SUPABASE_PUBLISHABLE_KEY:'test-public',SUPABASE_SECRET_KEY:'test-private'};
 const config=await handleAPI(new Request(origin+'/api/config'),env);const state=await config.json();assert.equal(state.ready,true);assert.equal(state.emailReady,false);
 const code=await handleAPI(new Request(origin+'/api/auth/code',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({email:'test@example.invalid'})}),env);assert.equal(code.status,503);assert.match((await code.json()).error,/temporarily unavailable/);
});
