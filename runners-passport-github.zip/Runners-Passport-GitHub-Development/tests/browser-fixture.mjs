// Isolated review UI fixture. No real customer data and no email is sent here.
// OTP stays in the approved private local config directory, never the repository.
import {readFile,writeFile,unlink} from 'node:fs/promises';
import {join} from 'node:path';
import {adminClient} from '../server/api.mjs';
const env=process.env;
if(env.REVIEW_ONLY!=='true'||env.TEST_LIVE_SUPABASE!=='true'||new URL(env.SUPABASE_URL).hostname!==env.REVIEW_PROJECT_REF+'.supabase.co')throw Error('Isolated review configuration required');
const admin=adminClient(env),path=join(env.LOCALAPPDATA,'RunnersPassport','browser-fixture.json');
const operation=process.argv[2];
if(operation==='create'){
 try{await readFile(path);throw Error('A fixture already exists; clean it up first.');}catch(e){if(e.code!=='ENOENT')throw e;}
 const email='rp-ui-'+crypto.randomUUID()+'@example.invalid';
 const invite=await admin.rpc('rp_invite_email',{p_email:email});if(invite.error)throw Error('Invitation failed');
 const {data,error}=await admin.auth.admin.createUser({email,email_confirm:true});if(error)throw Error('Fixture creation failed');
 await writeFile(path,JSON.stringify({id:data.user.id,email}));
 console.log('Disposable browser fixture created; identity stored privately. No email sent.');
}else{
 const fixture=JSON.parse(await readFile(path,'utf8'));
 if(!/^rp-ui-[0-9a-f-]+@example\.invalid$/.test(fixture.email))throw Error('Not a synthetic fixture');
 if(operation==='code'){
  const {data,error}=await admin.auth.admin.generateLink({type:'magiclink',email:fixture.email});if(error)throw Error('Test code generation failed');
  await writeFile(path,JSON.stringify({...fixture,code:data.properties.email_otp}));console.log('Test code stored privately. No email sent.');
 }else if(operation==='remove'){
  const assets=await admin.from('rp_assets').select('*').eq('owner_id',fixture.id);if(assets.error)throw Error('Cleanup manifest unavailable');
  for(const bucket of ['customer-photos','draft-previews']){const paths=assets.data.filter(a=>(a.kind==='photo')===(bucket==='customer-photos')).map(a=>a.path);if(paths.length){const result=await admin.storage.from(bucket).remove(paths);if(result.error)throw Error('Fixture files not removed');}}
  const revoke=await admin.rpc('rp_revoke_invite',{p_user:fixture.id});if(revoke.error)throw Error('Invitation cleanup failed');
  const result=await admin.auth.admin.deleteUser(fixture.id);if(result.error)throw Error('Fixture cleanup failed');
  await unlink(path);console.log('Disposable browser fixture and private code removed.');
 }else throw Error('Choose create, code or remove');
}
