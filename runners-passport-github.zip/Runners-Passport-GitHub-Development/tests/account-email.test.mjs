import test from 'node:test';
import assert from 'node:assert/strict';
import {requestEmailCode} from '../server/email-auth.mjs';

test('First login requests confirmation for an unconfirmed account with signup disabled',async()=>{
 const calls=[];
 const result=await requestEmailCode({
  signInWithOtp:async args=>{calls.push(args);return {error:{status:422,code:'signup_disabled'}};},
  resend:async args=>{calls.push(args);return {error:null};}
 },'first@example.invalid');
 assert.deepEqual(calls,[{email:'first@example.invalid',options:{shouldCreateUser:false}},{type:'signup',email:'first@example.invalid'}]);
 assert.equal(result.retryAfter,60);
});

test('Returning accounts request one OTP only',async()=>{
 let resent=false;
 await requestEmailCode({signInWithOtp:async()=>({error:null}),resend:async()=>{resent=true;}},'returning@example.invalid');
 assert.equal(resent,false);
});

test('Provider failures never become success responses or expose provider details',async()=>{
 for(const failedStage of ['initial','confirmation']){
  const failure={status:failedStage==='initial'?400:500,code:'unexpected_failure',message:'private provider details'};
  await assert.rejects(requestEmailCode({
   signInWithOtp:async()=>({error:failedStage==='initial'?failure:{status:422,code:'signup_disabled'}}),
   resend:async()=>({error:failure})
  },'failure@example.invalid'),e=>e.status===503&&!e.message.includes('private provider details'));
 }
});

test('Rate limits on first-login confirmation stay rate limits',async()=>{
 await assert.rejects(requestEmailCode({
  signInWithOtp:async()=>({error:{status:422,code:'signup_disabled'}}),
  resend:async()=>({error:{status:429,code:'over_email_send_rate_limit'}})
 },'rate@example.invalid'),e=>e.status===429);
});
