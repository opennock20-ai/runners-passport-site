// LIVE gate: isolated review project ONLY; creates synthetic users and deletes
// only those fixtures. Does not send email or use any existing customer's data.
import test from 'node:test';import assert from 'node:assert/strict';import {createClient} from '@supabase/supabase-js';
import {handleAPI,adminClient,runDeletionJobs} from '../server/api.mjs';
const env=process.env,enabled=env.TEST_LIVE_SUPABASE==='true';
test('Live Supabase: two customers, private files, migration, recovery and deletion',{skip:!enabled?'Supabase review credentials not configured; live isolation NOT verified':false},async t=>{
 assert.equal(env.REVIEW_ONLY,'true');assert(env.REVIEW_PROJECT_REF&&new URL(env.SUPABASE_URL).hostname===env.REVIEW_PROJECT_REF+'.supabase.co','Explicit isolated review project required');
 const admin=adminClient(env),opts={auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}};
 const customers=[],fixture=crypto.randomUUID();
 const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a8XYAAAAASUVORK5CYII=';
 async function api(c,path,method='GET',body,owner=c?.id){
  const headers={origin:env.APP_ORIGIN,...(body?{'content-type':'application/json'}:{}),...(c?.cookie?{cookie:c.cookie}:{}),...(owner?{'x-rp-account':owner}:{})};
  const r=await handleAPI(new Request(env.APP_ORIGIN+'/api/'+path,{method,headers,...(body?{body:JSON.stringify(body)}:{})}),env);
  if(c){const jar=new Map((c.cookie||'').split('; ').filter(Boolean).map(v=>{const i=v.indexOf('=');return [v.slice(0,i),v.slice(i+1)];}));for(const s of r.headers.getSetCookie()){const pair=s.split(';')[0],i=pair.indexOf('=');jar.set(pair.slice(0,i),pair.slice(i+1));}c.cookie=[...jar].map(([k,v])=>k+'='+v).join('; ');}
  return r;
 }
 async function login(c){const {data,error}=await admin.auth.admin.generateLink({type:'magiclink',email:c.email});assert(!error,'Test OTP generation failed');const r=await api(c,'auth/verify','POST',{email:c.email,code:data.properties.email_otp});assert.equal(r.status,200,'Review OTP verification must work');assert(r.headers.getSetCookie().every(x=>/HttpOnly/i.test(x)));return r;}
 try{
  for(const label of ['a','b']){
   const email=`rp-review-${fixture}-${label}@example.invalid`,password=crypto.randomUUID()+crypto.randomUUID();
   const allow=await admin.rpc('rp_invite_email',{p_email:email});assert(!allow.error,'Apply review migration first');
   const {data,error}=await admin.auth.admin.createUser({email,password,email_confirm:true});assert(!error,'Synthetic fixture creation failed');
   const c={id:data.user.id,email,cookie:'',client:createClient(env.SUPABASE_URL,env.SUPABASE_PUBLISHABLE_KEY,opts)};customers.push(c);
   const signed=await c.client.auth.signInWithPassword({email,password});assert(!signed.error,'Fixture login failed');await login(c);
  }
  const [a,b]=customers;const draft={id:'device-'+fixture,cardId:'nevis',name:'Synthetic isolation test',caption:'Test only',primary:'7h',distance:'1,345 m',date:'2026-06-20',photoPositionX:32,photoPosition:68,photoZoom:1.5,photo:image,preview:image};let saved;
  await t.test('A imports, retries without duplicates, and reads exact bytes and crop',async()=>{
   const first=await api(a,'drafts','POST',{draft,legacyId:draft.id});assert.equal(first.status,201);saved=(await first.json()).draft;
   const retry=await api(a,'drafts','POST',{draft,legacyId:draft.id});assert.equal((await retry.json()).draft.id,saved.id);
   assert.equal(saved.photoPositionX,32);assert.equal(saved.photoPosition,68);assert.equal(saved.photoZoom,1.5);
   const photo=await api(a,'assets/'+saved.photoId);assert.equal(photo.status,200);assert.equal(Buffer.from(await photo.arrayBuffer()).toString('base64'),image.split(',')[1]);assert.match(photo.headers.get('cache-control'),/no-store/);
  });
  await t.test('B and anonymous cannot access A via API, ordinary DB role or storage URL',async()=>{
   assert.equal((await api(b,'drafts/'+saved.id)).status,404);assert.equal((await api(b,'assets/'+saved.photoId)).status,404);assert.equal((await api(null,'drafts/'+saved.id)).status,401);
   const list=await b.client.from('rp_drafts').select('*').eq('id',saved.id);assert.deepEqual(list.data,[]);
   const asset=await a.client.from('rp_assets').select('*').eq('id',saved.photoId).single();assert(!asset.error);const path=asset.data.path;
   assert((await b.client.storage.from('customer-photos').download(path)).error);
   assert((await b.client.storage.from('customer-photos').upload(path,Uint8Array.of(1),{upsert:true,contentType:'image/png'})).error);
   await b.client.storage.from('customer-photos').remove([path]);assert(!(await a.client.storage.from('customer-photos').download(path)).error);
   assert((await b.client.from('rp_drafts').update({owner_id:b.id}).eq('id',saved.id)).error);
   assert((await b.client.rpc('rp_remove_draft',{p_id:saved.id,p_version:1})).error);
   assert.equal((await api(b,'drafts','POST',{draft},a.id)).status,409);
  });
  await t.test('Storage completion rejects bytes above reservation, including multipart',async()=>{
   const bytes=Buffer.from(image.split(',')[1],'base64');
   for(const body of [bytes,new Blob([bytes],{type:'image/png'})]){
    const r=await a.client.rpc('rp_reserve_asset',{p_kind:'photo',p_mime:'image/png',p_size:4});assert(!r.error);
    const asset=Array.isArray(r.data)?r.data[0]:r.data;
    const result=await a.client.storage.from('customer-photos').upload(asset.path,body,{contentType:'image/png'});
    assert(result.error,'Oversized object must fail the final storage policy');
    assert((await a.client.storage.from('customer-photos').download(asset.path)).error,'Rejected bytes must not be readable');
   }
  });
  await t.test('Conflicting updates and forged purchase fields are rejected',async()=>{
   const update=await api(a,'drafts','POST',{id:saved.id,version:1,draft:{...draft,caption:'Newer version'}});assert.equal(update.status,201);saved=(await update.json()).draft;
   assert.equal((await api(a,'drafts','POST',{id:saved.id,version:1,draft})).status,409);
   assert.equal((await api(a,'drafts','POST',{draft:{...draft,purchased:true}})).status,400);
  });
  await t.test('Recovery code reopens existing drafts; concurrent reads remain usable',async()=>{
   await api(a,'auth/logout','POST',{all:false});await login(a);
   const results=await Promise.all([api(a,'session'),api(a,'session')]);for(const r of results)assert.equal((await r.json()).user.id,a.id);
   const result=await api(a,'drafts/'+saved.id);assert.equal(result.status,200);
  });
  await t.test('Deletion locks old tokens, removes A, preserves B; worker retry is safe',async()=>{
   const r=await api(a,'account','DELETE',{confirm:'DELETE'});assert([200,202].includes(r.status));
   assert.equal((await a.client.from('rp_drafts').select('*')).data?.length||0,0);
   assert((await a.client.rpc('rp_reserve_asset',{p_kind:'photo',p_mime:'image/jpeg',p_size:4})).error);
   await runDeletionJobs(env);await runDeletionJobs(env);
   assert((await admin.auth.admin.getUserById(a.id)).error);
   assert.equal((await api(b,'session')).status,200);
  });
 }finally{
  // Synthetic fixture cleanup only. Never enumerate/delete unrelated users.
  for(const c of customers){const assets=await admin.from('rp_assets').select('*').eq('owner_id',c.id);for(const bucket of ['customer-photos','draft-previews']){const paths=(assets.data||[]).filter(a=>(a.kind==='photo')===(bucket==='customer-photos')).map(a=>a.path);if(paths.length)await admin.storage.from(bucket).remove(paths);}await admin.rpc('rp_revoke_invite',{p_user:c.id});await admin.auth.admin.deleteUser(c.id);}
 }
});
